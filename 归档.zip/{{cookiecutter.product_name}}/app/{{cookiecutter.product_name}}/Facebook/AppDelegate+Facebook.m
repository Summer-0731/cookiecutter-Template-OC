//
//  AppDelegate+Facebook.m
//  ExportUnityTest
//
//  Created by Summer on 2023/7/17.
//

#import "AppDelegate+Facebook.h"
#import "FacebookManager.h"

@implementation AppDelegate (Facebook)

- (void)facebookApplication:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions withlistener:(id<IFacebookListener>)listener {
    
    [NSClassFromString(@"FacebookInvoker") registerFacebookInvoker:self];
    [[FacebookManager getInstance] init:application didFinishLaunchingWithOptions:launchOptions withlistener:listener];
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    return [[FacebookManager getInstance] application:app openURL:url options:options];
}


/// <summary>
/// 登录
/// </summary>
- (void)login:(int)type {
    [[FacebookManager getInstance] login:type :[UIViewController new]];
}

/// <summary>
/// 注销
/// </summary>
- (void)logout {
    [[FacebookManager getInstance] logout:[UIViewController new]];
}


@end
