//
//  AppDelegate.h
//  {{cookiecutter.product_name}}
//
//  Created by Summer on 2023/7/28.
//

#import <UIKit/UIKit.h>
#include <UnityFramework/UnityFramework.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    bool enableLog;
    bool isGameReady;
    NSString* conversionData;
}

- (void)UnitySendMessage:(const char*)name :(const char*)msg;

- (void)checkSendConversion;

-(void) logEvent:(NSString*)eventName withJson:(NSString*) jsonString;

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UnityFramework *ufw;

@end

