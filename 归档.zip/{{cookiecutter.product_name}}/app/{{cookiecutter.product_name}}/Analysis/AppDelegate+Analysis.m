//
//  AppDelegate+Analysis.m
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate+Analysis.h"
#import "SSAnalyticsManager.h"
#import "FirebaseManager.h"

static NSString* TAG=@"AppDelegate (Analysis):";

@implementation AppDelegate (Analysis)

#pragma mark - AnalysisInvoker

-(void)initAnalysis{
    [NSClassFromString(@"AnalysisInvoker") registerAnalysisInvoker:self];
    [[AppsflyerManager getInstance]init:self :enableLog];
    [[FirebaseManager getInstance]init :enableLog];
    [[SSAnalyticsManager getInstance]init :enableLog];
}

/// <summary>
/// 设置统计UserId
/// </summary>
/// <param name="userId"></param>
-(void) setAnalysisUserId:(NSString*) userId{
    [[AppsflyerManager getInstance]setUserId:userId];
    [[FirebaseManager getInstance]setUserId:userId];
}
/// <summary>
/// 统计
/// </summary>
/// <param name="eventName"></param>
/// <param name="jsonStr"></param>
-(void) logEvent:(NSString*) eventName : (NSString*)  jsonStr{
    [[AppsflyerManager getInstance]trackEvent:eventName withJsonStr:jsonStr];
    [[FirebaseManager getInstance]trackEvent:eventName withJsonStr:jsonStr];
}

/// <summary>
/// 统计特殊事件
/// </summary>
/// <param name="eventName"></param>
/// <param name="jsonStr"></param>
-(void) logSpecialEvent:(NSString*) eventName : (NSString*)  jsonStr{
        [[AppsflyerManager getInstance]trackEvent:eventName withJsonStr:jsonStr];
        [[FirebaseManager getInstance]trackEvent:eventName withJsonStr:jsonStr];
}

/// <summary>
/// 统计
/// </summary>
/// <param name="eventName"></param>
/// <param name="jsonStr"></param>
-(void) logSSSDKEvent:(int) type : (NSString*) eventName : (NSString*) jsonStr {
    [[SSAnalyticsManager getInstance] trackEvent:type withEventName:eventName withJsonStr:jsonStr];
}

/// <summary>
/// 设置用户属性
/// </summary>
/// <param name="userId"></param>
/// <param name="jsonStr"></param>
- (void)onUserProperties:(int)type :(NSString *)jsonStr {
    
    [[SSAnalyticsManager getInstance]onUserProperties:type withJsonStr:jsonStr];
}

/// <summary>
/// 获取转化数据
/// </summary>
/// <returns></returns>
-(NSString*) getConversionData{
    return [[AppsflyerManager getInstance]getConversionData];
}

-(void) onReceiveConversionData:(NSString*) data{
    NSLog(@"%@%@",TAG,@"onReceiveConversionData");
    conversionData=data;
    [self checkSendConversion];
}

-(void) onConversionDataSuccess:(NSString*) conversionData{
    [self onReceiveConversionData:conversionData];
}
-(void) onConversionDataFail:(NSString*) errorMessage{
    
}

@end
