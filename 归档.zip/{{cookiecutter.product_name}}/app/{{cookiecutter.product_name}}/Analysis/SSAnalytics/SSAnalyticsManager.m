//
//  SSAnalyticsManager.m
//  Unity-iPhone
//
//  Created by apple on 2022/12/29.
//

#import "SSAnalyticsManager.h"

static SSAnalyticsManager* instance;
static NSString* TAG= @"SSAnalyticsManager :";

@implementation SSAnalyticsManager

+(SSAnalyticsManager *)getInstance{
    if(instance == NULL){
        instance=[SSAnalyticsManager alloc];
    }
    return instance;
}

-(void)init:(bool)log{

    enableLog=log;
    enable = [(NSNumber*)[[NSBundle mainBundle].infoDictionary objectForKey:@"enable_ss_analytics_sdk"]boolValue];
    NSString* appId = [[NSBundle mainBundle].infoDictionary objectForKey:@"ss_analytics_sdk_appid"];
    NSString* url = [[NSBundle mainBundle].infoDictionary
        objectForKey:@"ss_analytics_sdk_server_url"];
    if (enable) {
        sdkInstance = [ThinkingAnalyticsSDK startWithAppId:appId withUrl:url];
        if (sdkInstance!=NULL) {
            [ThinkingAnalyticsSDK setLogLevel:TDLoggingLevelDebug];
            
            [ThinkingAnalyticsSDK calibrateTimeWithNtp:@"time.apple.com"];
            //开启自动采集
            [sdkInstance enableAutoTrack:ThinkingAnalyticsEventTypeAppStart | ThinkingAnalyticsEventTypeAppEnd  | ThinkingAnalyticsEventTypeAppInstall];
            //设置公共事件属性
        }
    }
    
    NSLog(@"%@%@%d",TAG,@"inited end =enabled:",enable);
}

-(void)onUserProperties:(int)type withJsonStr:(nonnull NSString *)jsonStr{
    if (!enable) {
        return;
    }
    if(enableLog)
        NSLog(@"%@%@%d%@%@",TAG, @"onUserProperties type is :",type,@" jsonStr is :",jsonStr);
    NSData * jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSDictionary *eventValues = [NSJSONSerialization JSONObjectWithData:jsonData
    options:NSJSONReadingMutableContainers
      error:&err];
    
    if(jsonStr!=nil && ![jsonStr isEqualToString:@""] && !err && eventValues!=nil){
        switch (type) {
            case 1:
                // 设置用户属性
                [sdkInstance user_set:eventValues];
                break;
            case 2:
                // 设置单次属性
                [sdkInstance user_setOnce:eventValues];
                break;
            //todo add other userset
            default:
                break;
        }
    }
    
}
// 事件
-(void)trackEvent:(NSString*)eventName{
    if (!enable) {
        return;
    }
    NSDictionary* dic = [[NSDictionary alloc]init];
    [self trackEvent:eventName withValues:dic];
}

// 事件
-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr{
    if (!enable) {
        return;
    }
    if(enableLog)
        NSLog(@"%@%@%@%@%@",TAG, @"trackEvent eventName is :",eventName,@" jsonStr is :",jsonStr);
    NSData * jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSDictionary *eventValues = [NSJSONSerialization JSONObjectWithData:jsonData
    options:NSJSONReadingMutableContainers
      error:&err];
    
    if(jsonStr!=nil && ![jsonStr isEqualToString:@""] && !err && eventValues!=nil){
        [self trackEvent:eventName withValues:eventValues];
    }
    else{
        [self trackEvent:eventName];
    }
}
// 事件
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues{
    if (!enable) {
        return;
    }
    if(enableLog)
    NSLog(@"%@%@%@",TAG, @"trackEvent eventName is : dic",eventName);
    // 自定义事件埋点
    [sdkInstance track:eventName properties:eventValues];
}
// 事件
-(void)trackEvent:(int)type withEventName:(NSString*)eventName withJsonStr:(NSString*) jsonStr{
    if (!enable) {
        return;
    }
    if(enableLog)
    NSLog(@"%@%d%@%@",TAG, type,@"trackEvent eventName is : dic",eventName);
    NSData * jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSDictionary *eventValues = [NSJSONSerialization JSONObjectWithData:jsonData
    options:NSJSONReadingMutableContainers
      error:&err];
    if(jsonStr!=nil && ![jsonStr isEqualToString:@""] && !err && eventValues!=nil){
        
        switch (type) {
            case 2:
            {
                //首次事件
                TDFirstEventModel*firstModel = [[TDFirstEventModel alloc] initWithEventName:eventName];
                firstModel.properties = eventValues;
                [[ThinkingAnalyticsSDK sharedInstance] trackWithEventModel:firstModel];
            }
                break;
            case 3:
            {
                //可更新事件
                TDUpdateEventModel*updateModel = [[TDUpdateEventModel alloc] initWithEventName:eventName eventID:eventName];
                updateModel.properties = eventValues;
                [[ThinkingAnalyticsSDK sharedInstance] trackWithEventModel:updateModel];
            }
                break;
            case 4:
            {
                //可重写事件
                TDOverwriteEventModel*overwriteModel = [[TDOverwriteEventModel alloc] initWithEventName:eventName eventID:eventName];
                overwriteModel.properties = eventValues;
                [[ThinkingAnalyticsSDK sharedInstance] trackWithEventModel:overwriteModel];
            }
                break;
            default:
                //普通事件
                [sdkInstance track:eventName properties:eventValues];
                break;
        }
    }
    else{
        [self trackEvent:eventName];
    }
}
//
-(void)setCoustomUserId:(NSString*)userId{
    if (!enable) {
        return;
    }
    if (sdkInstance!=NULL) {
        [sdkInstance login:userId];
    }
}

-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict
{
    BOOL isYes = [NSJSONSerialization isValidJSONObject:dict];
    if (isYes)
    {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:NULL];
        NSString* jsonStr=[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonStr;
    }
    else
    {
        return @"";
    }
}

@end
