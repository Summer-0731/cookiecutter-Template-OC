//
//  AppsflyerManager.m
//  SdkSample
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AppsflyerManager.h"

static AppsflyerManager* instance;
static NSString* TAG= @"AppsflyerManager :";

@implementation AppsflyerManager

+(AppsflyerManager *)getInstance{
    if(instance == NULL){
        instance=[AppsflyerManager alloc];
    }
    return instance;
}

-(void)init:(id<IAppsflyerListener>) listener :(bool)log{
    appsflyerListner = listener;
    enableLog=log;
    
    NSString* devKey = [[NSBundle mainBundle].infoDictionary objectForKey:@"appsflyer_dev_key"];
    NSString* appleId = [[NSBundle mainBundle].infoDictionary objectForKey:@"appsflyer_apple_id"];
    
    // 初始化SDK
    [[AppsFlyerLib shared]setAppsFlyerDevKey:devKey];
    [[AppsFlyerLib shared]setAppleAppID:appleId];
    [[AppsFlyerLib shared]setDelegate:self];
    
    [[AppsFlyerLib shared]setIsDebug:enableLog];
    
    
    if(@available(iOS 10,*)){
        UNUserNotificationCenter* center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate=self;
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error) {
        }];
    }
    else{
        UIUserNotificationSettings* settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeAlert | UIUserNotificationTypeSound | UIUserNotificationTypeBadge) categories:nil];
        [[UIApplication sharedApplication]registerUserNotificationSettings:settings];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
        selector:@selector(trackAppLaunch:)
        name:UIApplicationDidBecomeActiveNotification
        object:nil];
    
    NSLog(@"%@%@",TAG,@"inited");
}

-(void)setUserId:(NSString*)userId{
    [AppsFlyerLib shared].customerUserID=userId;
}

-(void)trackAppLaunch:(UIApplication *)application{
    // 启动
    [[AppsFlyerLib shared]start];
}


-(BOOL)openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    [[AppsFlyerLib shared]handleOpenUrl:url options:options];  //
    return YES;
}

-(BOOL)openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    [[AppsFlyerLib shared]handleOpenURL:url sourceApplication:sourceApplication withAnnotation:annotation];  //
    return YES;
}

-(BOOL)continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler{
    [[AppsFlyerLib shared]continueUserActivity:userActivity restorationHandler:restorationHandler];  //
    return YES;
}

-(void)didReceiveRemoteNotification:(NSDictionary *)userInfo{
    // 处理通知
    [[AppsFlyerLib shared]handlePushNotification:userInfo];
}

- (void)onConversionDataSuccess:(NSDictionary *)conversionInfo{
    conversionData= [self dictionaryToJsonStr: conversionInfo];
    if(enableLog){
        NSLog(@"%@%@%@",TAG,@"onConversionDataSuccess :",conversionData);
    }
    // 成功信息打印
    [appsflyerListner onConversionDataSuccess:conversionData];
}

- (void)onConversionDataFail:(NSError *)error{
    if(enableLog)
    NSLog(@"%@%@%@",TAG, @"onConversionDataFail localizedFailureReason is :",error.localizedFailureReason);
    // 错误信息打印
    [appsflyerListner onConversionDataFail:error.localizedFailureReason];
}


-(void)trackEvent:(NSString*)eventName{
    NSDictionary* dic = [[NSDictionary alloc]init];
    [self trackEvent:eventName withValues:dic];//----1
}


-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr{
    if(enableLog)
        NSLog(@"%@%@%@%@%@",TAG, @"trackEvent eventName is :",eventName,@" jsonStr is :",jsonStr);
    NSData * jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSDictionary *eventValues = [NSJSONSerialization JSONObjectWithData:jsonData
    options:NSJSONReadingMutableContainers
      error:&err];
    
    if(jsonStr!=nil && ![jsonStr isEqualToString:@""] && !err && eventValues!=nil){
        [self trackEvent:eventName withValues:eventValues];  //----1
    }
    else{
        [self trackEvent:eventName];//----1.1
    }
}
//----2
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues{
    if(enableLog)
    NSLog(@"%@%@%@",TAG, @"trackEvent eventName is : dic",eventName);
    // 记录带有事件参数的事件。
    [[AppsFlyerLib shared]logEvent:eventName withValues:eventValues];
}

-(NSString*) getConversionData{
    return conversionData;
}

-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict
{
    BOOL isYes = [NSJSONSerialization isValidJSONObject:dict];
    if (isYes)
    {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:NULL];
        NSString* jsonStr=[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonStr;
    }
    else
    {
        return @"";
    }
}

@end
