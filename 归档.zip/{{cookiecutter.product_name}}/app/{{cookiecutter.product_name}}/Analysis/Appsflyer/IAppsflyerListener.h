//
//  AppsflyerReturnListener.h
//  SdkSample
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@protocol IAppsflyerListener

-(void) onConversionDataSuccess:(NSString*) conversionData;
-(void) onConversionDataFail:(NSString*) errorMessage;

@end

NS_ASSUME_NONNULL_END
