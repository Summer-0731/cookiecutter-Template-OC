/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Retrieves product information from the App Store using SKRequestDelegate, SKProductsRequestDelegate, SKProductsResponse, and
 SKProductsRequest. Notifies its observer with a list of products available for sale along with a list of invalid product identifiers. Logs an error
 message if the product request failed.
*/

#import <StoreKit/StoreKit.h>

//商品信息管理者，请求服务器上的商品信息，并储存
@interface StoreManager : NSObject
+ (StoreManager *)sharedInstance;

/// Indicates the cause of the product request failure.
@property (nonatomic, copy) NSString *message;


//商品类型,从客户端获得
@property(strong) NSMutableDictionary* productTypes;
//可购买的商品详情
@property(strong) NSMutableDictionary* availableProductDetailDic;
//不可购买的商品详情
@property (strong) NSMutableArray *invalidProductIdentifiers;

/// Keeps a strong reference to the product request.
@property (strong) SKProductsRequest *productRequest;

@property bool hasLoadedProducts;


/// <summary>
/// 初始化商品
/// </summary>
/// <param name="productJson"></param>
-(void) addProductJson:(NSString*) productJson;

//向服务器请求商品信息
-(void)fetchProductsMatchingIdentifiers;

-(int)getProductType:(NSString*)productId;
//获取商品信息
-(SKProduct*)getProduct:(NSString*)productId;

@end
