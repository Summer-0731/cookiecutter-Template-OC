//
//  InAppPurchaseErrorCode.h
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

typedef NS_ENUM(NSInteger,InAppPurchaseErrorCode) {
    //未知错误
    //Unknown error
    InAppPurchaseErrorCodeUNKNOWN = -1,

    //成功
    //Success.
    InAppPurchaseErrorCodeOK = 0,

    //版本库不支持
    //Billing API version is not supported for the type requested.
    InAppPurchaseErrorCodeBILLING_UNAVAILABLE = 1001,
    //play store不支持
    //Requested feature is not supported by Play Store on the current device.
    InAppPurchaseErrorCodeFEATURE_NOT_SUPPORTED = 1002,

    //与PlayStore通信中断
    //Play Store service is not connected now - potentially transient state.
    InAppPurchaseErrorCodeSERVICE_DISCONNECTED = 1101,
    //网络连接中断
    //Network connection is down.
    InAppPurchaseErrorCodeSERVICE_UNAVAILABLE = 1102,
    //网络连接超时
    //The request has reached the maximum timeout before Google Play responds.
    InAppPurchaseErrorCodeSERVICE_TIMEOUT = 1103,


    //商品不可购买,没有该商品
    //Requested product is not available for purchase.
    InAppPurchaseErrorCodeITEM_UNAVAILABLE = 1201,
    //消耗失败,因为没有该商品
    //Failure to consume since item is not owned.
    InAppPurchaseErrorCodeITEM_NOT_OWNED = 1202,
    //已经购买过该商品
    //Failure to purchase since item is already owned.
    InAppPurchaseErrorCodeITEM_ALREADY_OWNED = 1203,
    //已经奖励过该商品(已经奖励过该商品,自定义)
    //Product has already rewarded.
    InAppPurchaseErrorCodeITEM_ALREADY_REWARDED = 1204,

    //启动购买窗口失败
    //Launch flow failed
    InAppPurchaseErrorCodeLAUNCH_FLOW_FAIL = 1301,

    //用户取消
    //User pressed back or canceled a dialog.
    InAppPurchaseErrorCodeUSER_CANCELED = 1401,

    //错误开发者参数
    //Invalid arguments provided to the API.
    InAppPurchaseErrorCodeDEVELOPER_ERROR = 1501,

    //致命错误
    //Fatal error during the API action.
    InAppPurchaseErrorCodeERROR = 1601,
    
};
