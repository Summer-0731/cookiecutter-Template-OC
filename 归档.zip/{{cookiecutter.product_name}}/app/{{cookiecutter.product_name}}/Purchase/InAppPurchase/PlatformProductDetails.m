//
//  PlatformProductDetails.m
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

#import <Foundation/Foundation.h>
#import "PlatformProductDetails.h"

@implementation PlatformProductDetails

-(NSString*)toJsonString{
    return @"";
}

@end
