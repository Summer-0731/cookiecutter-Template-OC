//
//  StoreData.m
//  SdkSample
//
//  Created by Yanxi on 2020/11/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "StoreData.h"
#import <StoreKit/StoreKitDefines.h>

static NSDate* _date;

@implementation StoreData

+(NSDate*)date{
    return _date;
}

+(void)setDate:(NSDate *)date{
    _date=date;
}

//制作商品关键字
+(NSString*)makeProductKey:(NSString*)identifier{
    return [[NSString alloc]initWithFormat:@"productInfo_%@",identifier];
}
//制作已购关键字
+(NSString*)makePurchasedKey:(NSString*)identifier{
    return [[NSString alloc] initWithFormat:@"purchased_%@",identifier];
}
//设置购买过该商品
+(void)setPurchasedProduct:(NSString *)identifier{
    NSString* purchasedKey = [self makePurchasedKey:identifier];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:purchasedKey];
}
//是否购买过该商品
+(bool)isPurchasedProduct:(NSString *)identifier{
    NSString* purchasedKey = [self makePurchasedKey:identifier];
    return [[NSUserDefaults standardUserDefaults]boolForKey:purchasedKey];
}

//制作订单时间关键字
+(NSString*)makeTransactionDateKey:(NSString*)identifier{
    return [[NSString alloc] initWithFormat:@"transactionDate_%@",identifier];
}
//获取订单时间
+(NSData*) getTransactionData:(NSString*)identifier{
    NSString* transactionDateKey=[self makeTransactionDateKey:identifier];
    return  [[NSUserDefaults standardUserDefaults]objectForKey:transactionDateKey];
}
//设置订单时间
+(void) setTransactionData:(NSData*)transactionDate withIdentifier:(NSString*)identifier{
    NSString* transactionDateKey=[self makeTransactionDateKey:identifier];
    [[NSUserDefaults standardUserDefaults]setObject:transactionDate forKey:transactionDateKey];
}

//制作自动订阅关键字
+(NSString*)makeAutoSubscriptionKey:(NSString*)identifier{
    return [[NSString alloc] initWithFormat:@"autoSubscription_%@",identifier];
}
//保存商品为自动订阅
+(void)setAutoSubscription:(bool)isAutoSubscription withIdentifier:(NSString*)identifier{
    [[NSUserDefaults standardUserDefaults]setBool:isAutoSubscription forKey:[self makeAutoSubscriptionKey:identifier]];
}
//查询商品是否是自动订阅
+(bool)isAutoSubscription:(NSString*)identifier{
    return [[NSUserDefaults standardUserDefaults]boolForKey:[self makeAutoSubscriptionKey:identifier]];
}

//制作自动订阅周期关键字
+(NSString*)makeAutoSubscriptionUnitKey:(NSString*)identifier{
    return [[NSString alloc] initWithFormat:@"autoSubscriptionPeriodKey_%@",identifier];
}
//设置商品自动订阅周期
+(void)setAutoSubscriptionUnit:(NSUInteger)subscriptionPeriod withIdentifier:(NSString*)identifier{
    [[NSUserDefaults standardUserDefaults]setInteger:subscriptionPeriod forKey:[self makeAutoSubscriptionUnitKey:identifier]];
}
//获取自动订阅周期
+(NSUInteger)getAutoSubscriptionUnit:(NSString*)identifier{
    return [[NSUserDefaults standardUserDefaults]integerForKey:[self makeAutoSubscriptionUnitKey:identifier]];
}

//制作自动订阅数量关键字
+(NSString*)makeAutoSubscriptionNumberOfUnitsKey:(NSString*)identifier{
    return [[NSString alloc] initWithFormat:@"autoSubscriptionCountKey_%@",identifier];
}
//设置商品自动订阅数量
+(void)setAutoSubscriptionNumberOfUnits:(NSUInteger)subscriptionCount withIdentifier:(NSString*)identifier{
    [[NSUserDefaults standardUserDefaults]setInteger:subscriptionCount forKey:[self makeAutoSubscriptionNumberOfUnitsKey:identifier]];
}
//获取商品自动订阅数量
+(NSUInteger)getAutoSubscriptionNumberOfUnits:(NSString*)identifier{
    return [[NSUserDefaults standardUserDefaults]integerForKey:[self makeAutoSubscriptionNumberOfUnitsKey:identifier]];
}

//设置自动订阅的商品
+(void)setAutoSubscriptionInfo:(SKProduct *)product withIdentifier:(NSString *)identifier{
    if(product.subscriptionPeriod!=nil){
        [self setAutoSubscription:product.subscriptionPeriod!=nil withIdentifier:identifier];
        [self setAutoSubscriptionUnit:product.subscriptionPeriod.unit withIdentifier:identifier];
        [self setAutoSubscriptionNumberOfUnits:product.subscriptionPeriod.numberOfUnits withIdentifier:identifier];
    }
}

+(void)handlePurchasedTransaction:(SKPaymentTransaction *)transaction{
    [self handlePurchaseOrRestoreProduct:transaction];
}

+(void)handleRestoredTransaction:(SKPaymentTransaction *)transaction{
    [self handlePurchaseOrRestoreProduct:transaction];
}

+(void)handlePurchaseOrRestoreProduct:(SKPaymentTransaction *)transaction{
    NSString* identifier = transaction.payment.productIdentifier;
    [self setPurchasedProduct:identifier];

    //若是自动订阅，则设置自动订阅购买时间
    if([self isAutoSubscription:identifier]){
        NSString* transactionDateKey=[self makeTransactionDateKey:identifier];
        
        NSDate* transactionDate = [self getTransactionData:identifier];
        if(transactionDate==nil || [transaction.transactionDate compare:transactionDate] > 0 ){
            transactionDate = transaction.transactionDate;
        }
        [self setTransactionData:transactionDate withIdentifier:identifier];
    }
}

+(bool)isAutoSubscriptionAvailable:(NSString *)identifier{
    return [self getLeftAutoSubscriptionAvailableDay:identifier]>0;
}

+(int)getLeftAutoSubscriptionAvailableDay:(NSString *)identifier{
    if([self isAutoSubscription:identifier]){
        NSString* transactionDateKey=[self makeTransactionDateKey:identifier];
        NSDate* transactionDate = [[NSUserDefaults standardUserDefaults]objectForKey:transactionDateKey];
        
        if(transactionDate==nil){
            return 0;
        }
        else{
            NSDateComponents* dateComponents = [[NSDateComponents alloc]init];
            NSCalendar* calendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
            
            NSInteger unit = [self getAutoSubscriptionUnit:identifier];
            NSInteger numberOfUnits= [self getAutoSubscriptionNumberOfUnits:identifier];
            
            switch (unit) {
                case SKProductPeriodUnitDay:
                    dateComponents.day=numberOfUnits;
                    break;
                case SKProductPeriodUnitWeek:
                    dateComponents.weekdayOrdinal=numberOfUnits;
                    break;
                case SKProductPeriodUnitMonth:
                    dateComponents.month=numberOfUnits;
                    break;
                case SKProductPeriodUnitYear:
                    dateComponents.year=numberOfUnits;
                    break;
                default:
                    break;
            }
            //计算自动订阅有效期
            NSDate* availableDate = [calendar dateByAddingComponents:dateComponents toDate:transactionDate options:0];
            NSDate* nowDate;
//            if(_date!=nil){
//                nowDate=_date;
//            }
//            else{
//                nowDate = [NSDate date];
//            }
            nowDate = [NSDate date];
            
            // NSDateComponents* components = [calendar components:NSCalendarUnitDay fromDate:nowDate toDate:availableDate options:0];
            //已经过期
            if([availableDate compare:nowDate]<0){
                return 0;
            }
            else{
                NSDateComponents* components = [calendar components:NSCalendarUnitDay fromDate:nowDate toDate:availableDate options:0];
                int leftDay;
                if([components hour]+[components minute]+[components second]>1){
                    leftDay = [components day]+1;
                }
                else{
                    leftDay =  [components day];
                }
                NSLog(@"leftDay is : %D",leftDay);
                return leftDay;
            }
        }
    }
    return 0;
}

@end
