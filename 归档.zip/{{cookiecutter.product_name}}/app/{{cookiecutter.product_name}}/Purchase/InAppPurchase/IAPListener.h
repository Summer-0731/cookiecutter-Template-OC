//
//  IAPListener.h
//  SdkSample
//
//  Created by Yanxi on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol IAPListener

//商品购买成功回调
-(void)onPurchaseSuccess:(NSString*)identifier:(NSString*)transactionIdentifier;
//商品购买失败回调
-(void)onPurchaseFailed:(NSString*)identifier :(NSString*)errorMessage;
//商品restore回调
-(void)onProductRestored:(NSString*)identifier;
//商品restore完毕回调
-(void)onProductResotredCompleted;
//商品restore失败回调
-(void)onProductResotredError:(NSString*)localizedDescription;


//
///// <summary>
///// 查询商品详情成功回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onQueryProductDetailSuccess:(NSString*) returnCode;
///// <summary>
///// 查询商品详情失败回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onQueryProductDetailFailed:(NSString*) returnCode;
///// <summary>
///// 商品购买成功回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onPurchaseSuccess:(NSString*) returnCode;
///// <summary>
///// 商品购买失败回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onPurchaseFailed:(NSString*) returnCode;
//
///// <summary>
///// 商品补发成功回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onReissueProduct:(NSString*) returnCode;
//
///// <summary>
///// 商品restore回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onProductRestored:(NSString*) returnCode;
///// <summary>
///// 商品restore完毕回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onProductRestoredCompleted:(NSString*) returnCode;
///// <summary>
///// 商品restore失败回调
///// </summary>
///// <param name="returnCode"></param>
//-(void) onProductRestoredError:(NSString*) returnCode);

@end

NS_ASSUME_NONNULL_END
