//
//  InApppurchaseUtils.h
//  IOSUseUnityProject
//
//  Created by mac on 2022/11/1.
//



@interface InApppurchaseUtils : NSObject

+(int)convertResponseCodeToErrorCode:(int)responseCode;
+(NSString*) getErrorCodeMsg:(int) errorCode;

@end
