//
//  IAPManager.h
//  SdkSample
//
//  Created by Yanxi on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAPListener.h"
#import "InAppPurchaseListener.h"
#import "PlatformProductDetails.h"
#import "InAppPurchaseError.h"

NS_ASSUME_NONNULL_BEGIN

@interface InAppPurchaseManager : NSObject{
    id<IInAppPurchaseListener> inAppPurchaseListener;
    bool enableLog;
}

+(InAppPurchaseManager*)getInstance;

//app启动成功，didFinishLaunchingWithOptions时调用
-(void)init:(id<IInAppPurchaseListener>)listener:(bool)log;
//app结束，applicationWillTerminate时调用
-(void)appEnded;


/// <summary>
/// 初始化商品
/// </summary>
/// <param name="productJson"></param>
-(void) addProductJson:(NSString*) productJson;

/// <summary>
/// 购买商品
/// </summary>
/// <param name="productId"></param>
-(void) purchase:(NSString*) productId;

/// <summary>
/// 恢复已购商品
/// </summary>
-(void) restore;

/// <summary>
/// 是否购买过该商品,卸载重装后,需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isPurchasedProduct:(NSString*) productId;
/// <summary>
/// 自动订阅是否有效，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isAutoSubscriptionAvailable:(NSString*) productId;
/// <summary>
/// 获取自动订阅剩余天数，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(int) getLeftAutoSubscriptionAvailableDay:(NSString*) productId;



//请求服务器商品信息成功
-(void )onQueryProductDetailSuccess:(PlatformProductDetails*) platformProductDetails;

//请求服务器商品信息失败
-(void )onQueryProductDetailFailed:(InAppPurchaseError*) inAppPurchaseError;

//购买成功
-(void) onPurchaseSuccess:(NSString*) productId:(NSString*) purchaseToken;

//重新发放商品
-(void) onReissueProduct:(NSString*) productId:(NSString*) purchaseToken;

//购买失败
-(void )onPurchaseFailed:(InAppPurchaseError*) inAppPurchaseError;

//restore成功
-(void )onProductRestored:(NSString*) productId;

//restore结束
-(void) onProductRestoredCompleted;

//restore失败
-(void) onProductRestoredError:(InAppPurchaseError*) inAppPurchaseError;


//-(void)onPurchaseSuccess:(NSString*)identifier:(NSString*)transactionIdentifier;
//-(void)onPurchaseFailed:(NSString*)identifier:(NSString*)errorMessage;
//-(void)onProductRestored:(NSString*)identifier;
//-(void)onProductResotredCompleted;
//-(void)onProductResotredError:(NSString*)localizedDescription;
//
////收到商品信息
//-(void)onReceiveProductResponse;

@end

NS_ASSUME_NONNULL_END
