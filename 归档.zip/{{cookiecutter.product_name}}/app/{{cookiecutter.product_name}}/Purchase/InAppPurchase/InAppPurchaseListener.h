//
//  IInAppPurchaseListener.h
//  IOSUseUnityTest
//
//  Created by mac on 2022/10/31.
//
#import <Foundation/Foundation.h>

@protocol IInAppPurchaseListener
/// <summary>
/// 查询商品详情成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onQueryProductDetailSuccess:(NSString*) returnCode;
/// <summary>
/// 查询商品详情失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onQueryProductDetailFailed:(NSString*) returnCode;
/// <summary>
/// 商品购买成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onPurchaseSuccess:(NSString*) returnCode;
/// <summary>
/// 商品购买失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onPurchaseFailed:(NSString*) returnCode;

/// <summary>
/// 商品补发成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onReissueProduct:(NSString*) returnCode;

/// <summary>
/// 商品restore回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestored:(NSString*) returnCode;
/// <summary>
/// 商品restore完毕回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestoredCompleted:(NSString*) returnCode;
/// <summary>
/// 商品restore失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestoredError:(NSString*) returnCode;

@end

