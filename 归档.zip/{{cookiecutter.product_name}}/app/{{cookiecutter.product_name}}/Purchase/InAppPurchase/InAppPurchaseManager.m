//
//  IAPManager.m
//  SdkSample
//
//  Created by Yanxi on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <StoreKit/StoreKit.h>

#import "InAppPurchaseManager.h"
#import "StoreObserver.h"
#import "StoreManager.h"
#import "StoreData.h"
#import "PlatformProductDetails.h"
#import "InAppPurchaseError.h"
#import "InAppPurchaseErrorCode.h"
#import "InApppurchaseUtils.h"

static InAppPurchaseManager* instance;
static NSString* TAG = @"InAppPurchaseManager";

@interface InAppPurchaseManager ()

//购买成功的商品id
@property (strong) NSMutableArray *purchasedSuccessIdentifiers;
//购买成功的订单id
@property (strong) NSMutableDictionary *purchasedSuccessTransactionIdentifier;
//购买失败的商品id
@property (strong) NSMutableArray *purchasedFailedIdentifiers;
//restore恢复购买的商品id
@property (strong) NSMutableArray *restoredIdentifiers;

//检查没发送的信息
-(void)checkUnSendMessage;

@end

@implementation InAppPurchaseManager

+(InAppPurchaseManager*) getInstance{
    if(instance==nil){
        instance= [[InAppPurchaseManager alloc]init];
    }
    return instance;
}

-(instancetype)init{
    self = [super init];
    if(self!=nil){
        _purchasedSuccessIdentifiers=[[NSMutableArray alloc]initWithCapacity:0];
        _purchasedSuccessTransactionIdentifier=[[NSMutableDictionary alloc]initWithCapacity:0];
        _purchasedFailedIdentifiers=[[NSMutableArray alloc]initWithCapacity:0];
        _restoredIdentifiers=[[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

-(void)init:(id<IInAppPurchaseListener>)listener:(bool)log{
    inAppPurchaseListener = listener;
    enableLog=log;
    [[SKPaymentQueue defaultQueue]addTransactionObserver:[StoreObserver sharedInstance]];
}

-(void)appEnded{
    [[SKPaymentQueue defaultQueue]removeTransactionObserver:[StoreObserver sharedInstance]];
    
}


/// <summary>
/// 初始化商品
/// </summary>
/// <param name="productJson"></param>
-(void) addProductJson:(NSString*) productJson{
    [[StoreManager sharedInstance]addProductJson:productJson];
    
    [self checkUnSendMessage];
}

/// <summary>
/// 购买商品
/// </summary>
/// <param name="productId"></param>
-(void) purchase:(NSString*) productId{
    if(enableLog)
    NSLog(@"%@:purchase productId is : %@",TAG,productId);
    SKProduct* skproduct=[[StoreManager sharedInstance ]getProduct:productId];
    //有该商品则购买
    if(skproduct!=nil){
        [[StoreObserver sharedInstance] buy:skproduct];
    }
    //没有该商品
    else{
        InAppPurchaseError* purchaseError = [[InAppPurchaseError alloc]init:productId :InAppPurchaseErrorCodeITEM_UNAVAILABLE :[InApppurchaseUtils getErrorCodeMsg:InAppPurchaseErrorCodeITEM_UNAVAILABLE]];
        [[InAppPurchaseManager getInstance]onPurchaseFailed:purchaseError];
    }
}

/// <summary>
/// 恢复已购商品
/// </summary>
-(void) restore{
    if(enableLog)
        NSLog(@"%@:restore",TAG);
    [[StoreObserver sharedInstance]restore];
}

/// <summary>
/// 是否购买过该商品,卸载重装后,需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isPurchasedProduct:(NSString*) productId{
    if(enableLog)
        NSLog(@"%@:isPurchasedProduct",TAG);
    return [StoreData isPurchasedProduct:productId];
}
/// <summary>
/// 自动订阅是否有效，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isAutoSubscriptionAvailable:(NSString*) productId{
    if(enableLog)
        NSLog(@"%@:isAutoSubscriptionAvailable",TAG);
    return [StoreData isAutoSubscriptionAvailable:productId];
}
/// <summary>
/// 获取自动订阅剩余天数，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(int) getLeftAutoSubscriptionAvailableDay:(NSString*) productId{
    if(enableLog)
    NSLog(@"%@:getLeftAutoSubscriptionAvailableDay, productId is :%@",TAG, productId);
    return [StoreData getLeftAutoSubscriptionAvailableDay:productId];
}



//// region InAppPurchaseListener
//请求服务器商品信息成功
-(void )onQueryProductDetailSuccess:(PlatformProductDetails*) platformProductDetails {
    if(enableLog)
    NSLog(@"%@:onQueryProductDetailSuccess, platformProductDetails is :%@",TAG, [platformProductDetails toJsonString]);
    [inAppPurchaseListener onQueryProductDetailSuccess: platformProductDetails.toJsonString];
}

//请求服务器商品信息失败
-(void )onQueryProductDetailFailed:(InAppPurchaseError*) inAppPurchaseError{
    if(enableLog)
    NSLog(@"%@:onQueryProductDetailFailed: error code is : %d error msg is :%@",TAG,inAppPurchaseError.errorCode,inAppPurchaseError.errorMsg);
    [inAppPurchaseListener onQueryProductDetailFailed: inAppPurchaseError.toJsonString];
}

//购买成功
-(void) onPurchaseSuccess:(NSString*) productId:(NSString*) purchaseToken {
    if(enableLog)
    NSLog(@"%@:onPurchaseSuccess productId is : %@",TAG,productId);
    [inAppPurchaseListener onPurchaseSuccess:productId];
}

//重新发放商品
-(void) onReissueProduct:(NSString*) productId:(NSString*) purchaseToken{
    if(enableLog)
    NSLog(@"%@:onReissueProduct productId is : %@",TAG,productId);
    [inAppPurchaseListener onReissueProduct:productId];
}

//购买失败
-(void )onPurchaseFailed:(InAppPurchaseError*) inAppPurchaseError {
    if(enableLog)
    NSLog(@"%@:onPurchaseFailed: error code is : %d error msg is :%@",TAG,inAppPurchaseError.errorCode,inAppPurchaseError.errorMsg);
    [inAppPurchaseListener onPurchaseFailed: inAppPurchaseError.toJsonString];
}

//restore成功
-(void )onProductRestored:(NSString*) productId {
    if(enableLog)
    NSLog(@"%@:onProductRestored productId is : %@",TAG,productId);
    [inAppPurchaseListener onProductRestored:productId];
}

//restore结束
-(void) onProductRestoredCompleted {
    if(enableLog)
    NSLog(@"%@:onProductRestoredCompleted",TAG);
    [inAppPurchaseListener onProductRestoredCompleted:@""];
}

//restore失败
-(void) onProductRestoredError:(InAppPurchaseError*) inAppPurchaseError {
    if(enableLog)
    NSLog(@"%@:onProductRestoredError: error code is : %d error msg is :%@",TAG,inAppPurchaseError.errorCode,inAppPurchaseError.errorMsg);
    [inAppPurchaseListener onProductRestoredError:inAppPurchaseError.toJsonString];
}
//// endregion


-(void)checkUnSendMessage{
    NSLog(@"%@:checkUnSendMessage",TAG);
    if([self.purchasedSuccessIdentifiers count]>0){
        for (NSString* identifier in self.purchasedSuccessIdentifiers) {
            [self onPurchaseSuccess:identifier:@""];
        }
        [self.purchasedSuccessIdentifiers removeAllObjects];
        [self.purchasedSuccessTransactionIdentifier removeAllObjects];
    }
    if([self.restoredIdentifiers count]>0){
        for (NSString* identifier in self.restoredIdentifiers) {
            [self onProductRestored:identifier];
        }
        [self.restoredIdentifiers removeAllObjects];
    }
}

@end
