//
//  AppDelegate.m
//  {{cookiecutter.product_name}}
//
//  Created by Summer on 2023/7/28.
//

#import "AppDelegate.h"

#import "Ad/AppDelegate+Ad.h"
#import "Analysis/AppDelegate+Analysis.h"
#import "Utility/AppDelegate+Utility.h"
#import "Notification/AppDelegate+Notification.h"
//#import "Purchase/AppDelegate+Purchase.h"
#import "AppDelegate+Facebook.h"

static NSString* TAG=@"AppDelegate :";
const char* unityObjectName ="CrossPlatformHelper";

/* UnityFrameworkLoad */
UIKIT_STATIC_INLINE UnityFramework* UnityFrameworkLoad()
{
    NSString* bundlePath = nil;
    bundlePath = [[NSBundle mainBundle] bundlePath];
    bundlePath = [bundlePath stringByAppendingString: @"/Frameworks/UnityFramework.framework"];

    NSBundle* bundle = [NSBundle bundleWithPath: bundlePath];
    if ([bundle isLoaded] == false) [bundle load];

    UnityFramework* ufw = [bundle.principalClass getInstance];
    if (![ufw appController])
    {
        // unity is not initialized
        [ufw setExecuteHeader: &_mh_execute_header];
    }
    return ufw;
}

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:launchOptions forKey:@"launchOptions"];
    [userDefaults synchronize];
    
    [self initUnity];
    
    enableLog = [(NSNumber*)[[NSBundle mainBundle].infoDictionary objectForKey:@"enable_log"]boolValue];
    [self initAd];
    [self initAnalysis];
    [self initUtility];
    [self initNotification];
    
    [self facebookApplication:application didFinishLaunchingWithOptions:launchOptions withlistener:self];
    
    
//    [self initPurchase];
    
    return YES;
}

#pragma mark - Unity

- (BOOL)unityIsInitialized
{
    return [self ufw] && [[self ufw] appController];
}

- (void)initUnity
{
    /* 判断Unity 是否已经初始化 */
    if ([self unityIsInitialized]) return;
    /* 初始化Unity */
    self.ufw = UnityFrameworkLoad();
    [self.ufw setDataBundleId:"com.unity3d.framework"];

    NSString *argvStr = [[NSUserDefaults standardUserDefaults] valueForKey:@"argv"];
    char **argv;
    sscanf([argvStr cStringUsingEncoding:NSUTF8StringEncoding], "%p",&argv);
    int argc = [[[NSUserDefaults standardUserDefaults] valueForKey:@"argc"] intValue];
    NSDictionary *launchOptions = [[NSUserDefaults standardUserDefaults] valueForKey:@"launchOptions"];

    [self.ufw runEmbeddedWithArgc:argc argv:argv appLaunchOpts:launchOptions];
    
    self.window=self.ufw.appController.window;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[[self ufw] appController] applicationWillResignActive: application];
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[[self ufw] appController] applicationDidEnterBackground: application];
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[[self ufw] appController] applicationWillEnterForeground: application];
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[[self ufw] appController] applicationDidBecomeActive: application];
}
- (void)applicationWillTerminate:(UIApplication *)application {
    [[[self ufw] appController] applicationWillTerminate: application];
}


- (void)UnitySendMessage:(const char*)name :(const char*)msg{
    [[UnityFramework getInstance] sendMessageToGOWithName:unityObjectName functionName:name message:msg];
}

-(void)checkSendConversion{
    if(isGameReady && conversionData!=nil){
        [self UnitySendMessage:"OnReceiveConversionData":[conversionData cStringUsingEncoding:NSUTF8StringEncoding]];
    }
}

-(void) logEvent:(NSString*)eventName withJson:(NSString*) jsonString{
    [self logEvent:eventName :jsonString];
}
@end
