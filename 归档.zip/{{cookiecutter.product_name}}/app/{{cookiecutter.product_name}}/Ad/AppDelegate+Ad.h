//
//  AppDelegate+Ad.h
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate.h"

#import <UnityFramework/AdInvoker.h>
#import "ApplovinMax/IAdListener.h"
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import "ApplovinMax/AdManager.h"
#import "ApplovinMax/IAdLogEventListenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Ad)<IAdInvoker,IAdListener,IAdLogEventListenter>

-(void)initAd;

-(void)logAdEvent:(NSString*)eventName withJson:(NSString*) jsonStr;



@end

NS_ASSUME_NONNULL_END
