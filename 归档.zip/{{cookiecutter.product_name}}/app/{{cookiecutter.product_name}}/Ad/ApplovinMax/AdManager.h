//
//  AdManager.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppLovinSDK/AppLovinSDK.h"
#import "IAdListener.h"
#import "BannerAdDecorator.h"
#import "InterstitialAdDecorator.h"
#import "RewardedAdDecorator.h"
#import "IAdLogEventListenter.h"
#import <InMobiSDK/IMUnifiedIdService.h>

NS_ASSUME_NONNULL_BEGIN


@interface AdManager : NSObject<IAdStateListener>{
    //,IMUnifiedIdDelegate
    BannerAdDecorator* bannerAdDecorator;
    InterstitialAdDecorator* interstitialAdDecorator;
    RewardedAdDecorator* rewardedAdDecorator;
    
    bool isInited;
    
    bool enableLog;
    NSString* bannerAdUnitId;
    bool bannerVisible;
    NSString* interstitialAdUnitId;
    NSString* rewardedAdUnitId;
    bool showMediationDebugger;
    
    id<IAdListener> adListener;
    id<IAdLogEventListenter> adLogEventListener;
    
}


+(AdManager*)getInstance;

-(void)init:(id<IAdListener>)iAdListener :(bool)log :(id<IAdLogEventListenter>)iAdLogEventListenter;


-(bool)isEmptyString:(NSString*) str;

-(void)setUserIdentifier:(NSString*)userId;
-(void)showBannerAd:(NSString*)placement;
-(void)hideBannerAd;
-(bool)isInterstitialAdReady;
-(void)showInterstitialAd:(NSString*)placement;
-(bool)isRewardedAdReady;
-(void)showRewardedAd:(NSString*)placement;
-(void)initAd:(BOOL)showBanner;

@end

NS_ASSUME_NONNULL_END
