//
//  InterstitialAdDecorator.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdDecorator.h"
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface InterstitialAdDecorator : AdDecorator{
    MAInterstitialAd *interstitialAd;
}

-(instancetype)init:(NSString*) adUnitId withAdStateListener:(id<IAdStateListener>) iAdStateListener;
    
@end

NS_ASSUME_NONNULL_END
