//
//  AdManager.m
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AdManager.h"
#import "AdType.h"
#import <StoreKit/SKAdNetwork.h>
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <InMobiSDK/InMobiSDK.h>
#import <InMobiSDK/IMUnifiedIdService.h>

static AdManager* instance;
static NSString* TAG=@"AdManager :";
@implementation AdManager

+(AdManager *)getInstance{
    if(instance == NULL){
        instance=[AdManager alloc];
    }
    return instance;
}

-(void)init:(id<IAdListener>)iAdListener :(bool)log :(id<IAdLogEventListenter>)iTrackEventListener{
    adListener = iAdListener;
    enableLog = log;
    adLogEventListener = iTrackEventListener;
    
    if(@available(iOS 14.0,*)){
        [SKAdNetwork registerAppForAdNetworkAttribution];
    }
    
    // 获取广告ID以及广告详细日志
    showMediationDebugger = [(NSNumber*)[[NSBundle mainBundle].infoDictionary objectForKey:@"max_ad_show_mediation_debugger"]boolValue];
    bannerVisible = [(NSNumber*)[[NSBundle mainBundle].infoDictionary objectForKey:@"max_ad_banner_visible"]boolValue];
    
    bannerAdUnitId = [[NSBundle mainBundle].infoDictionary objectForKey:@"max_ad_banner_unitId"];
    interstitialAdUnitId = [[NSBundle mainBundle].infoDictionary objectForKey:@"max_ad_interstitial_unitId"];
    rewardedAdUnitId = [[NSBundle mainBundle].infoDictionary objectForKey:@"max_ad_reward_unitId"];
    
    if(enableLog){
        NSLog(@"%@%@%@%@%@%@%@",TAG,@"AdManager : init: bannerAdUnitId is ", bannerAdUnitId, @" interstitialAdUnitId is ",interstitialAdUnitId,@" rewardedAdUnitId is",rewardedAdUnitId);
    }
    if(self->showMediationDebugger){
//        [ALSdk shared].settings.isVerboseLogging = YES;
        // 打印日志
        [[ALSdk shared].settings setVerboseLoggingEnabled:YES];
    }
    [ALSdk shared].mediationProvider = @"max";
    // summer_999
    [ALSdk shared].userIdentifier = [[NSBundle mainBundle].infoDictionary objectForKey:@"AppLovinSdkKey"];
    [[ALSdk shared] initializeSdkWithCompletionHandler:^(ALSdkConfiguration *configuration) {
        if(self->enableLog){
            NSLog(@"AdManager : initializeSdkCompleted");
        }
        if(@available(iOS 14.5,*)){
            // 设置用户是否同意广告跟踪权限
                ATTrackingManagerAuthorizationStatus status = ATTrackingManager.trackingAuthorizationStatus;
            if(status == ATTrackingManagerAuthorizationStatusAuthorized){
                [FBAdSettings setAdvertiserTrackingEnabled:YES];
            }
            else{
                [FBAdSettings setAdvertiserTrackingEnabled:NO];
            }
        }
        else if(@available(iOS 14,*)){
            [FBAdSettings setAdvertiserTrackingEnabled:YES];
        }
        
        // SDK 设置
        if(self->showMediationDebugger){
            [[ALSdk shared]showMediationDebugger];
            [[ALSdk shared].settings setIsVerboseLogging:YES];
            [[ALSdk shared].settings setVerboseLoggingEnabled:YES];
        }
        else{
//            [ALSdk shared].settings.isVerboseLogging = NO;
            // 详细日志
            [[ALSdk shared].settings setVerboseLoggingEnabled:NO];
        }
        if([self isEmptyString:self->bannerAdUnitId]){
            // banner广告
            self->bannerAdDecorator = [[BannerAdDecorator alloc] init:self->bannerAdUnitId withAdStateListener:self];
        }
        
        if([self isEmptyString:self->interstitialAdUnitId]){
            // 插页式广告
            self->interstitialAdDecorator = [[InterstitialAdDecorator alloc]init:self->interstitialAdUnitId withAdStateListener:self];
        }
        
        if([self isEmptyString:self->rewardedAdUnitId]){
            // 激励视频
            self->rewardedAdDecorator = [[RewardedAdDecorator alloc]init:self->rewardedAdUnitId withAdStateListener:self];
        }
        
        if(self->bannerVisible){
            [self showBannerAd:@""];
        }
        else{
            [self hideBannerAd];
        }
        self->isInited = true;
        
        //初始化inmobi sdk
        if([[NSBundle mainBundle].infoDictionary objectForKey:@"inmobi_accountId"]){
            NSString* accountId =  [[NSBundle mainBundle].infoDictionary objectForKey:@"inmobi_accountId"];
            NSDictionary * consentDictionary = @{IM_GDPR_CONSENT_AVAILABLE:@"true",IM_GDPR_CONSENT_IAB:@"<>"};
            [IMSdk initWithAccountID:accountId consentDictionary:consentDictionary andCompletionHandler:^(NSError * _Nullable error) {
                if (error==NULL) {
                    NSLog(@"AdManager IMSdk initWithAccountID:successs");
                    IMUserDataModel *userDataModel = [[[IMUserDataModel alloc]init] initWithPhoneNumber:nil emailId:nil extras:nil];
                    [IMUnifiedIdService push:userDataModel];
                    [IMUnifiedIdService fetchUnifiedIds:self];
                } else {
                    NSLog(@"AdManager IMSdk initWithAccountID:failed==%@",error);
                }
            }];
        }
    }];
}
-(bool)isEmptyString:(NSString*) str{
    if(str!=nil && str!= NULL
    && ![str isKindOfClass:[NSNull class]]
       && [[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]!=0){
        return true;
    }
    return false;
}
- (void)onFetchCompleted:(nullable NSDictionary *)response error:(nullable NSError *)error
{
    if (error==NULL) {
        NSLog(@"onFetch imunifid Completed success %@",response);
    } else {
        NSLog(@"onFetch imunifid Completed error %@",error);
    }
}

- (void) setUserIdentifier:(NSString*) userId{
    [ALSdk shared].userIdentifier = userId;
}

-(void)showBannerAd:(NSString*)placement{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"showBannerAd");
    bannerVisible=true;
    if(bannerAdDecorator!=nil){
        [bannerAdDecorator show:placement];
    }
}

-(void)hideBannerAd{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"hideBannerAd");
    bannerVisible=false;
    if(bannerAdDecorator!=nil){
        [bannerAdDecorator hide];
    }
}

-(bool)isInterstitialAdReady{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"isInterstitialAdReady");
    if(interstitialAdDecorator!=nil){
        return [interstitialAdDecorator isReady];
    }
    return false;
}

-(void)showInterstitialAd:(NSString*)placement{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"showInterstitialAd");
    if(interstitialAdDecorator!=nil){
        [interstitialAdDecorator show:placement];
    }
}

-(bool)isRewardedAdReady{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"isRewardedAdReady");
    if(rewardedAdDecorator!=nil){
        return [rewardedAdDecorator isReady];
    }
    return false;
}

-(void)showRewardedAd:(NSString*)placement{
    if(enableLog)
        NSLog(@"%@%@",TAG,@"showRewardedAd");
    if(rewardedAdDecorator!=nil){
        [rewardedAdDecorator show:placement];
    }
}

-(void)onAdCreated:(NSString*)adType adUnitIdIs:(NSString*)adUnitId{
    if(enableLog){
        NSLog(@"%@%@%@%@%@", TAG,@"onAdCreated: adType = ",adType,@" adUnitId = ",adUnitId);
    }
}
-(void)loadAd:(NSString*)adType adUnitIdIs:(NSString*)adUnitId{
    if(enableLog){
        NSLog(@"%@%@%@%@%@", TAG,@"loadAd: adType = ",adType,@" adUnitId = ",adUnitId);
    }
    
}
-(void)onAdLoaded:(NSString*)adType adUnitIdIs:(NSString*)adUnitId{
    if(enableLog){
        NSLog(@"%@%@%@%@%@,", TAG,@"onAdLoaded: adType = ",adType,@" adUnitId = ",adUnitId);
    }
    
    if(adType == AdType.bannerType){
        [adListener onBannerAdLoadState:true];
        if(bannerVisible)
            [self showBannerAd:@""];
        else
            [self hideBannerAd];
    }
    else if(adType == AdType.interstitialType){
        [adListener onInterstitialAdLoadState:true];
    }
    else if(adType == AdType.rewardedType){
        [adListener onRewardedAdLoadState:true];
    }
}
-(void)onAdLoadFailed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId errorCodeIs:(int)errorCode{
    if(enableLog){
        NSLog(@"%@%@%@%@%@%@%d", TAG,@"onAdLoadFailed: adType = ",adType,@" adUnitId = ",adUnitId, @" errorCode is ", errorCode);
    }
    if(adType == AdType.bannerType){
        [adListener onBannerAdLoadState:false];
    }
    else if(adType == AdType.interstitialType){
        [adListener onInterstitialAdLoadState:false];
    }
    else if(adType == AdType.rewardedType){
        [adListener onRewardedAdLoadState:false];
    }
//    NSDictionary * eventValues = @{@"adUnitId":adUnitId,@"errorCode":[NSString stringWithFormat:@"%d",errorCode]};
//    [self logAdEvent:@"adLoadFailed" withValues:eventValues]
}
-(void)onAdDisplayed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId adPlacemnt:(nonnull NSString *)placement{
    if(enableLog)
        NSLog(@"%@%@%@%@%@", TAG,@"onAdDisplayed adType = ",adType,@" adUnitId = ",adUnitId);
    if(adType == AdType.interstitialType){
        [adListener onInterstitialAdDisplay];
        [self logAdEvent:@"ad_inter"];
        [self logAdEvent:placement];
    }
    else if(adType == AdType.rewardedType){
        [adListener onRewardedAdDisplay];
        [self logAdEvent:@"ad_video"];
        [self logAdEvent:placement];
    }
}
-(void)onAdDisplayFailed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId errorCodeIs:(int)errorCode{
    if(enableLog)
        NSLog(@"%@%@%@%@%@%@%d", TAG,@"onAdDisplayFailed: adType = ",adType,@" adUnitId = ",adUnitId, @" errorCode is ", errorCode);
}
-(void)onAdHidden:(NSString*)adType adUnitIdIs:(NSString*)adUnitId isWatchCompleted:(bool)isWatchCompleted{
    if(enableLog)
    NSLog(@"%@%@%@%@%@%@%d", TAG,@"onAdHidden: adType = ",adType,@" adUnitId = ",adUnitId, @" isWatchCompleted is ", isWatchCompleted);
    if(adType == AdType.interstitialType){
        [adListener onInterstitialAdHidden];
    }
    else if(adType == AdType.rewardedType){
        [adListener onRewardedAdHidden:isWatchCompleted];
    }
}
-(void)onAdClicked:(NSString*)adType adUnitIdIs:(NSString*)adUnitId{
    if(enableLog)
        NSLog(@"%@%@%@%@%@",TAG,@"onAdClicked: adType = ", adType,@" adUnitId = " , adUnitId);
}

-(void)onRewardedAdStart:(NSString*)adUnitId{
    if(enableLog)
        NSLog(@"%@%@%@%@",TAG,@"onRewardedAdStart: adType = " ,@" adUnitId = " , adUnitId);
    
}
-(void)onRewardedAdComplete:(NSString*)adUnitId{
    if(enableLog)
        NSLog(@"%@%@%@%@",TAG,@"onRewardedAdComplete: adType = " ,@" adUnitId = " , adUnitId);
    [adListener onRewardedAdComplete];
}
-(void)onRewardedAdReward:(NSString*)adUnitId{
    if(enableLog)
        NSLog(@"%@%@%@%@",TAG,@"onRewardedAdReward: adType = ", @" adUnitId = " , adUnitId);
    [adListener onUserRewarded];
}

-(void) logAdEvent:(NSString*) eventName{
    NSDictionary * eventValues = [[NSDictionary alloc]init];
    [self logAdEvent:eventName eventValues:eventValues];
}

-(void) logAdEvent:(NSString*) eventName eventValues:(NSDictionary*) eventValues{
    if(adLogEventListener!=nil){
        if(eventValues == nil || eventValues.count==0){
            [adLogEventListener logAdEvent:eventName withJson:@""];
        }
        else
        {
            NSError *error;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:eventValues options:NSJSONWritingSortedKeys
                                                error:&error];
            NSString *jsonString;
            if (!jsonData) {
                NSLog(@"%@",error);
            } else {
                jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
            }
            [adLogEventListener logAdEvent:eventName withJson:jsonString];
        }
    }
}
- (void)initAd:(BOOL)showBanner {

}
@end

