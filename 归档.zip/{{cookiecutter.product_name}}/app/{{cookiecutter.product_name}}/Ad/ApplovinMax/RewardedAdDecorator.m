//
//  RewardedAdDecorator.m
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "RewardedAdDecorator.h"
#import "AdType.h"

@implementation RewardedAdDecorator

-(instancetype)init:(NSString *)adUitId withAdStateListener:(id<IAdStateListener>)iAdStateListener{
    if(self = [super init:adUitId withAdStateListener:iAdStateListener]){
        rewardedAd = [MARewardedAd sharedWithAdUnitIdentifier:adUitId];
        rewardedAd.delegate = self;
        isWatchCompleted = false;
        self.load;
    }
    return self;
}

-(NSString*)getAdType{
    return AdType.rewardedType;
}

-(void)load{
    [adStateListener loadAd:self.getAdType adUnitIdIs:adUnitId];
    rewardedAd.loadAd;
}

-(bool)isNeedRetry{
    return true;
}

-(bool)isReady{
    return rewardedAd.isReady;
}

-(void)show:(NSString*)placement{
    self->placement=placement;
    if(self.isReady){
        rewardedAd.showAd;
    }
}

-(void)didDisplayAd:(MAAd *)ad{
    [super didDisplayAd:ad];
    isWatchCompleted=false;
}

-(void)didHideAd:(MAAd *)ad{
    [adStateListener onAdHidden:self.getAdType adUnitIdIs:adUnitId isWatchCompleted:isWatchCompleted];
    [super didHideAd:ad];
}

-(void)didStartRewardedVideoForAd:(MAAd *)ad{
    [adStateListener onRewardedAdStart:ad.adUnitIdentifier];
}

-(void)didCompleteRewardedVideoForAd:(MAAd *)ad{
    [adStateListener onRewardedAdComplete:ad.adUnitIdentifier];
    isWatchCompleted=true;
}

-(void)didRewardUserForAd:(MAAd *)ad withReward:(MAReward *)reward{
    [adStateListener onRewardedAdReward:ad.adUnitIdentifier];
}

@end
