//
//  RewardedAdDecorator.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdDecorator.h"
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface RewardedAdDecorator : AdDecorator<MARewardedAdDelegate>{
    MARewardedAd* rewardedAd;
    bool isWatchCompleted;
}

@end

NS_ASSUME_NONNULL_END
