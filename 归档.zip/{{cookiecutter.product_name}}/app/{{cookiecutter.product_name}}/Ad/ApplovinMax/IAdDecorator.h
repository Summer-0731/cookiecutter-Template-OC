//
//  IAdDecorator.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol IAdDecorator
    @required
    -(void) load;
    -(bool) isNeedRetry;
    -(void) delayLoad:(long) millis;
    -(bool) isReady;
    -(void) show:(NSString*)placement;
    -(NSString*) getAdType;
@end

NS_ASSUME_NONNULL_END

