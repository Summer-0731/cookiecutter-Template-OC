//
//  AdDecorator.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IAdDecorator.h"
#import "IAdStateListener.h"
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface AdDecorator : NSObject<MAAdDelegate,IAdDecorator>{
    int retryAttempt;
    
    NSString* adUnitId;
    id<IAdStateListener> adStateListener;
    NSString* placement;
    
}

-(instancetype)init:(NSString*) adUitId withAdStateListener:(id<IAdStateListener>) iAdStateListener;

@end

NS_ASSUME_NONNULL_END
