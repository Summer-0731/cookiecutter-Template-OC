//
//  NotificationInfo.h
//  Unity-iPhone
//
//  Created by apple on 2021/3/17.
//

NS_ASSUME_NONNULL_BEGIN

@interface NotificationInfo : NSObject{
    @public
    int notificationId;
    NSString* title;
    NSString* content;
    int hour;
    int minute;
    int second;
    int timeType;
    int loop;
    long loopInterval;
    long createTimeSecond;
}
-(instancetype)init:(int)notificationId :(NSString*)title :(NSString*)content
                   :(int)hour :(int)minute :(int)second :(int)timeType :(int)loop :(long) loopInterval;

@end

NS_ASSUME_NONNULL_END
