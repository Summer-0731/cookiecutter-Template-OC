//
//  AppDelegate+Notification.h
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate.h"

#import <UnityFramework/NotificationInvoker.h>
#import "SystemNotification/NotificationManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Notification)<INotificationInvoker>

-(void)initNotification;

@end

NS_ASSUME_NONNULL_END
