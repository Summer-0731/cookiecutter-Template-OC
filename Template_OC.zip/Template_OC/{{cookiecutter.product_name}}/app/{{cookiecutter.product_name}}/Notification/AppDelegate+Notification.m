//
//  AppDelegate+Notification.m
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate+Notification.h"

@implementation AppDelegate (Notification)

#pragma mark - NotificationInvoker

-(void)initNotification{
    [NSClassFromString(@"NotificationInvoker") registerNotificationInvoker:self];
    [[NotificationManager getInstance]initState];
}
-(int) addNotification:(int) notificationId: (NSString*) title :(NSString*) content:(int) hour:(int) minute:(int) second: (int) timeType:(int) loop: (long) loopInterval{
    return [[NotificationManager getInstance]addNotification:notificationId :title :content :hour :minute :second :timeType :loop :loopInterval];
}
-(void) removeNotification:(int) notificationId{
    [[NotificationManager getInstance]removeNotification:notificationId];
}

@end
