//
//  NotificationUtils.m
//  SdkSample
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "NotificationManager.h"

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0
#import <UserNotifications/UserNotifications.h>
#endif

#define LocalNotiReqIdentifer    @"LocalNotiReqIdentifer"

static NotificationManager* instance;

@implementation NotificationManager

+(NotificationManager *)getInstance{
    if(instance == NULL){
        instance = [[NotificationManager alloc]init];
    }
    return instance;
}

-(void)initState{
    //初始化通知相关，检测通知开启状态，且移除之前的通知
    [self checkNotificationSwitchState];
    [self removeAllNotification];
    notificationInfos = [[NSMutableDictionary alloc]init];
}


-(int)addNotification:(int)notificationId :(NSString *)title :(NSString *)body :(int)hour :(int)minute :(int)second :(int)timeType :(int)loop :(long)loopInterval{
    NotificationInfo* notificationInfo = [[NotificationInfo alloc]init:notificationId :title :body :hour :minute :second :timeType :loop :loopInterval];
    
    [self->notificationInfos setValue:notificationInfo forKey:[NSString stringWithFormat:@"%d",notificationInfo->notificationId]];
    
    int beginId = notificationId*200+1;
    [self sendLocalNotification:beginId :title :body :hour :minute :second :timeType];
    
    int loopCount=loop;
    if(loopCount<0||loopCount>100){
        loopCount=100;
    }
    if(loopCount>0){
        long leftSecond=0;
        if(timeType==0){
            leftSecond=(hour*60+minute)*60+second;
        }
        else if(timeType==1){
            NSCalendar *calendar = [NSCalendar currentCalendar];
            NSDate *nowDate = [NSDate date];
            NSDateComponents *dateComponents = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:nowDate];
            dateComponents.hour= hour;
            dateComponents.minute= minute;
            dateComponents.second= second;
            NSDate * targetDate = [calendar dateFromComponents:dateComponents];
            long targetSecondInterval = [targetDate timeIntervalSince1970];
            long nowSecondInterval=[nowDate timeIntervalSince1970];
            if(targetSecondInterval>nowSecondInterval){
                leftSecond=targetSecondInterval-nowSecondInterval;
            }
            else{
                leftSecond=targetSecondInterval+86400-nowSecondInterval;
            }
        }
        int loopBeginId= notificationId*200+100;
        for (int i=1; i<=loopCount; i++) {
            long totalSecond = leftSecond+i*loopInterval;
            int loopHour = totalSecond/(60*60);
            int loopMinute =totalSecond/60;
            int loopSecond = totalSecond % 60;
            [self sendLocalNotification:loopBeginId+i :title :body :loopHour :loopMinute :loopSecond :0];
        }
    }
    return beginId;
}

-(void)removeNotification:(int)notificationId{
    NSString* key =[NSString stringWithFormat:@"%d",notificationId];
    if([[self->notificationInfos allKeys]containsObject:key]){
        NotificationInfo* notificationInfo = [self->notificationInfos valueForKey:key];
        
        int beginId=notificationId*200+1;
        [self cancelNotification:beginId];
        int loopCount =notificationInfo->loop;
        if(loopCount<0||loopCount>100){
            loopCount=100;
        }
        if(loopCount>0){
            int loopBeginId= notificationId*200+100;
            for (int i=1; i<=loopCount; i++) {
                [self cancelNotification:loopBeginId+i];
            }
        }
    }
}

#pragma mark -- 检测通知 开关状态
- (void)checkNotificationSwitchState{
    if (@available(iOS 10.0,*)) {
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
            if (settings.notificationCenterSetting != UNNotificationSettingEnabled){
                [self openNotification];
            }
        }];
    }else{
        UIUserNotificationSettings * settings = [[UIApplication sharedApplication] currentUserNotificationSettings];
        if(settings.types == UIUserNotificationTypeNone){
            [self openNotification];
        }
    }
}

//打开通知权限
-(void)openNotification{
    if (@available(iOS 10.0,*)) {
        // iOS10 及以上
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        [center requestAuthorizationWithOptions:UNAuthorizationOptionAlert | UNAuthorizationOptionBadge | UNAuthorizationOptionSound completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (granted) {
                NSLog(@"通知权限注册成功");
                // 注册成功
            }else{
                NSLog(@"通知权限注册失败");
                // 注册失败
            }
        }];
    }else{
        // iOS8 及以上
        UIUserNotificationSettings *setting = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert categories:nil];
        
        [[UIApplication sharedApplication] registerUserNotificationSettings:setting];
    }
}

-(void)sendLocalNotification:(int)notificationId :(NSString*)title :(NSString*)body
                            :(int)hour :(int)minute :(int)second :(int)timeType{
    if (@available(iOS 10.0,*)) {
        // 通知中心
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        // 通知内容
        UNMutableNotificationContent * content = [[UNMutableNotificationContent alloc]init];
        content.title = title;
        content.subtitle = @"";
        content.body = body;
        // 默认铃声
        content.sound = [UNNotificationSound defaultSound];
        // 角标
        content.badge = @1;
        
        UNNotificationTrigger * trigger;
        switch (timeType) {
            case 0:
            {
                double totalSecond=((hour*60)+minute)*60+second;
                // 设置多长时间之后发送
                NSTimeInterval intervale = [[NSDate dateWithTimeIntervalSinceNow:totalSecond] timeIntervalSinceNow];
                trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:intervale repeats:NO];
                
            }
                break;
            case 1:{
                NSDateComponents* dateComponents= [[NSDateComponents alloc]init];
                dateComponents.hour= hour;
                dateComponents.minute=minute;
                dateComponents.second= second;
                trigger = [UNCalendarNotificationTrigger triggerWithDateMatchingComponents:(dateComponents) repeats:YES];
                
            }
                break;
            default:
                break;
        }
        

        
        // 通知请求
        // id：便于以后移除、更新 指定通知
        UNNotificationRequest * request = [UNNotificationRequest requestWithIdentifier:[NSString stringWithFormat:@"%d",notificationId] content:content trigger:trigger];
        // 添加通知请求
        [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
            if (error == nil) {
                NSLog(@"本地推送成功");
            }
            else{
                NSLog(@"本地推送失败");
            }
        }];
        
    }else{
        UILocalNotification * locationNotice = [[UILocalNotification alloc]init];
        // 发送时间
        NSDate* date;
        switch (timeType) {
            case 0:{
                
                double totalSecond=((hour*60)+minute)*60+second;
                date = [NSDate dateWithTimeIntervalSinceNow:totalSecond];
                
            }
                break;
            case 1:{
                date = [NSDate alloc];
                NSCalendar *calendar = [NSCalendar currentCalendar];
                NSDate *now = [NSDate date];
                NSDateComponents *dateComponents = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:now];
                dateComponents.hour= hour;
                dateComponents.minute= minute;
                dateComponents.second= second;
                locationNotice.repeatInterval = 24*60*60;
            }
                
                break;
                default:
                
                break;
        }
        locationNotice.fireDate = date;
        // 通知内容
        locationNotice.alertTitle= title;
        locationNotice.alertBody = body;
        locationNotice.userInfo = @{@"noticeId":[NSString stringWithFormat:@"%d",notificationId]};
        // 默认铃声
        locationNotice.soundName = UILocalNotificationDefaultSoundName;
        locationNotice.repeatInterval = NSCalendarUnitDay;
        // 循环提醒
        // 角标
        locationNotice.applicationIconBadgeNumber = 1;
        // 发送
        [[UIApplication sharedApplication] scheduleLocalNotification:locationNotice];
    }
}

//取消通知
-(void)cancelNotification:(int)notificationId{
    NSString*noticeID=[NSString stringWithFormat:@"%d",notificationId];
    if (@available(iOS 10.0,*)) {
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        // 判断noticeID是否存在
        [center getPendingNotificationRequestsWithCompletionHandler:^(NSArray<UNNotificationRequest *> * _Nonnull requests) {
            for (UNNotificationRequest * request in requests) {
                if([noticeID isEqualToString:request.identifier]){
                    [center removePendingNotificationRequestsWithIdentifiers:@[noticeID]];
                }
            }
        }];
        
    }else{
        // 获取scheduled中的通知
        NSArray * scheduledArray = [[UIApplication sharedApplication] scheduledLocalNotifications];
        
        for (UILocalNotification * localNotice in scheduledArray) {
            NSDictionary * userInfo = localNotice.userInfo;
            NSString * userNoticeID = [userInfo objectForKey:@"noticeId"];
            if ([userNoticeID isEqualToString:noticeID]) {
                [[UIApplication sharedApplication] cancelLocalNotification:localNotice];
            }
        }
    }
}

//移除所有通知
- (void)removeAllNotification{
    if (@available(iOS 10.0,*)) {
        UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
        [center removeAllPendingNotificationRequests];
    }else{
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
    }
}

@end

