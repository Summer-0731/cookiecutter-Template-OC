//
//  NotificationInfo.m
//  Unity-iPhone
//
//  Created by apple on 2021/3/17.
//

#import <Foundation/Foundation.h>
#import "NotificationInfo.h"

@implementation NotificationInfo

-(instancetype)init:(int)notificationId :(NSString*)title :(NSString*)content
                   :(int)hour :(int)minute :(int)second :(int)timeType :(int)loop :(long) loopInterval{
    self->notificationId = notificationId;
    self->title=title;
    self->content=content;
    self->hour=hour;
    self->minute=minute;
    self->second=second;
    self->timeType=timeType;
    self->loop=loop;
    self->loopInterval=loopInterval;
    self->createTimeSecond=([[NSDate date] timeIntervalSince1970]);
    return self;
}




@end
