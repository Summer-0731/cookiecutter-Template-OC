//
//  NotificationUtils.h
//  SdkSample
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "NotificationInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface NotificationManager : NSObject{
    NSMutableDictionary* notificationInfos;
}

+(NotificationManager*)getInstance;

-(void)initState;

//添加通知
-(int)addNotification:(int)notificationId :(NSString*)title :(NSString*)content
                     :(int)hour :(int)minute :(int)second :(int)timeType :(int)loop :(long) loopInterval;
//移除通知
-(void)removeNotification:(int)notificationId;

//发送本地通知
-(void)sendLocalNotification:(int)notificationId :(NSString*)title :(NSString*)body
                            :(int)hour :(int)minute :(int)second :(int)timeType;
//移除某个通知
-(void)cancelNotification:(int)notificationId;

//检查通知开关
-(void) checkNotificationSwitchState;
//开启通知
-(void)openNotification;
//移除所有通知
-(void)removeAllNotification;

@end



NS_ASSUME_NONNULL_END
