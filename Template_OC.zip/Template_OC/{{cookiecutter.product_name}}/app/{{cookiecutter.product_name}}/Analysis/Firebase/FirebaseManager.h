//
//  FirebaseManager.h
//  NativeIOS
//
//  Created by Machals on 2022/4/13.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN



@interface FirebaseManager:NSObject{
    bool enableLog;
}
+(FirebaseManager*)getInstance;

-(void)init:(bool)log;
-(void)setUserId:(NSString*)userId;

-(void)trackEvent:(NSString*)eventName;
-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr;
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues;

-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
