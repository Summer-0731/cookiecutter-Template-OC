//
//  FirebaseManager.m
//  IOSUseUnityTest
//
//  Created by mac on 2022/10/19.
//

#import <Foundation/Foundation.h>
#import "FirebaseManager.h"

@import Firebase;

static FirebaseManager* instance;
static NSString* TAG= @"FirebaseManager :";


@implementation FirebaseManager

+(FirebaseManager *)getInstance{
    if(instance == NULL){
        instance=[FirebaseManager alloc];
    }
    return instance;
}



-(void)init:(bool)log{
    enableLog=log;
    [FIRApp configure];// 配置应用 从磁盘读取GoogleService-Info.plist
    [FIRAnalytics setAnalyticsCollectionEnabled:true]; // 设置是否在此设备上为此应用启用分析收集
}
// 设置用户 ID
-(void)setUserId:(NSString*)userId{
    [FIRAnalytics setUserID:userId];
}
// 事件
-(void)trackEvent:(NSString*)eventName{
    NSDictionary* dic = [[NSDictionary alloc]init];
    [self trackEvent:eventName withValues:dic]; ///---1
}

// 事件
-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr{
    if(enableLog)
        NSLog(@"%@%@%@%@%@",TAG, @"trackEvent eventName is :",eventName,@" jsonStr is :",jsonStr);
    NSData * jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSDictionary *eventValues = [NSJSONSerialization JSONObjectWithData:jsonData
    options:NSJSONReadingMutableContainers
      error:&err];
    
    if(jsonStr!=nil && ![jsonStr isEqualToString:@""] && !err && eventValues!=nil){
        [self trackEvent:eventName withValues:eventValues]; ///---1
    }
    else{
        [self trackEvent:eventName]; ///---1.1
    }
}
// 事件 ///---2
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues{
    if(enableLog)
    NSLog(@"%@%@%@",TAG, @"trackEvent eventName is : dic",eventName);
    // 自定义事件
    [FIRAnalytics logEventWithName:eventName parameters:eventValues];
}

-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict
{
    BOOL isYes = [NSJSONSerialization isValidJSONObject:dict];
    if (isYes)
    {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:0 error:NULL];
        NSString* jsonStr=[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonStr;
    }
    else
    {
        return @"";
    }
}

@end

/*
*  https://firebase.google.com/docs/analytics/events?hl=zh-cn&platform=ios#objective-c_1
*  在 Xcode 调试控制台中查看事件
*  您可以启用详细日志记录功能以监控 SDK 的事件记录，从而帮助验证是否正确记录了事件，包括自动和手动记录的事件。
*  您可以按如下方式启用详细日志记录功能：
*  1、在 Xcode 中，依次选择 Product > Scheme > Edit scheme…
*  2、从左侧菜单中选择 Run。
*  3、选择 Arguments 标签页。
*  4、在 Arguments Passed On Launch 部分，添加 -FIRAnalyticsVerboseLoggingEnabled。
*  下次您运行应用时，事件将显示在 Xcode 调试控制台中，有助于您即时验证事件是否正在发送。
*/
