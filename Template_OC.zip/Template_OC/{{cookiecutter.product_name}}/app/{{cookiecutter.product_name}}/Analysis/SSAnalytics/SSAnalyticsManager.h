//
//  SSAnalyticsManager.h
//  Unity-iPhone
//
//  Created by apple on 2022/12/29.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ThinkingSDK.h"

NS_ASSUME_NONNULL_BEGIN

@interface SSAnalyticsManager : NSObject{
    bool enableLog;
    ThinkingAnalyticsSDK* sdkInstance;
    bool enable;
}
+(SSAnalyticsManager*)getInstance;

-(void)init:(bool)log;
-(void)trackEvent:(NSString*)eventName;
-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr;
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues;
-(void)trackEvent:(int)type withEventName:(NSString*)eventName withJsonStr:(NSString*) jsonStr;
// 设置自定义用户ID
-(void)setCoustomUserId:(NSString*)userId;
// 用户属性
-(void)onUserProperties:(int)type withJsonStr:(NSString*) jsonStr;
-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
