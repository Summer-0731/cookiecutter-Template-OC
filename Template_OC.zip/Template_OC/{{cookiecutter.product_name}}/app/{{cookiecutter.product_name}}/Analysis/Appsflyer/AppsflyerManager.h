//
//  AppsflyerManager.h
//  SdkSample
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AppsFlyerLib/AppsFlyerLib.h>
#import "IAppsflyerListener.h"
#import <UserNotifications/UNUserNotificationCenter.h>
#import <UserNotifications/UserNotifications.h>

NS_ASSUME_NONNULL_BEGIN


@interface AppsflyerManager : NSObject<AppsFlyerLibDelegate,UNUserNotificationCenterDelegate>{
    id<UIApplicationDelegate> applicationDelegate;
    bool enableLog;
    id<IAppsflyerListener> appsflyerListner;
    NSString* conversionData;
}

+(AppsflyerManager*)getInstance;

-(void)init:(id<IAppsflyerListener>) listener :(bool)log;
-(void)setUserId:(NSString*)userId;

-(void)trackAppLaunch:(UIApplication *)application;

-(BOOL)openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;
-(BOOL)openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;
-(BOOL)continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler;
-(void)didReceiveRemoteNotification:(NSDictionary *)userInfo;

-(void)trackEvent:(NSString*)eventName;
-(void)trackEvent:(NSString*)eventName withJsonStr:(NSString*) jsonStr;
-(void)trackEvent:(NSString*)eventName withValues:(NSDictionary*) eventValues;

-(NSString*) getConversionData;

-(NSString*)dictionaryToJsonStr:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
