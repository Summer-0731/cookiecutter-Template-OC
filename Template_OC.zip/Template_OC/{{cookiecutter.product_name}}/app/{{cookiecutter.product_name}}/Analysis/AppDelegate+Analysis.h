//
//  AppDelegate+Analysis.h
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate.h"

#import <UnityFramework/AnalysisInvoker.h>
#import "Appsflyer/IAppsflyerListener.h"
#import "Appsflyer/AppsflyerManager.h"
//#import "Firebase/FirebaseManager.h"


NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Analysis)<IAnalysisInvoker,IAppsflyerListener>

-(void)initAnalysis;
-(void) logEvent:(NSString*) eventName : (NSString*)  jsonStr;

@end

NS_ASSUME_NONNULL_END
