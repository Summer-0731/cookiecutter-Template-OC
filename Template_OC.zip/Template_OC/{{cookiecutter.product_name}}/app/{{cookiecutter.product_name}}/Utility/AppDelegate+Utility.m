//
//  AppDelegate+Utility.m
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate+Utility.h"

static NSString* TAG=@"AppDelegate (Utility):";

@implementation AppDelegate (Utility)

#pragma mark - PlatformUtilityInvoker

-(void)initUtility{
    [NSClassFromString(@"PlatformUtilityInvoker") registerPlatformUtilityInvoker:self];
}

/// <summary>
/// 游戏初始化完成
/// </summary>
-(void) gameInitReady{
    isGameReady=true;
    [self checkSendConversion];
}

/// <summary>
/// 震动
/// </summary>
/// <param name="duration">持续时间</param>
/// <param name="repeat">重复几次pattern,-1表示不重复</param>
-(void) vibrator:(float) duration : (int) repeat{
    [PlatformUtilityManager vibrator:duration :repeat];
}

/// <summary>
/// 获取语言
/// </summary>
/// <returns></returns>
-(NSString*) getLanguageCode{
    return [PlatformUtilityManager getLanguageCode];
}

/// <summary>
/// 获取国家
/// </summary>
/// <returns></returns>
-(NSString*) getRegionCode{
    return [PlatformUtilityManager getRegionCode];
}

/// <summary>
/// 获取版本名
/// </summary>
/// <returns></returns>
-(NSString*) getAppVersion{
    return [PlatformUtilityManager getAppVersion];
}

/// <summary>
/// 获取刘海高度
/// </summary>
/// <returns></returns>
-(int) getNotchHeight{
    return [PlatformUtilityManager getNotchHeight];
}

/// <summary>
/// 应用内评价
/// </summary>
-(void) showReview{
    [PlatformUtilityManager showReview];
}

/// <summary>
/// 获取唯一标识符
/// </summary>
/// <returns></returns>
-(NSString*) getUniqueId{
    return [PlatformUtilityManager getUniqueId];
}

/// <summary>
/// 获取设备Id
/// </summary>
/// <returns></returns>
-(NSString*) getDeviceId{
    return [PlatformUtilityManager getDeviceId];
}

/// <summary>
/// 获取开机后到此时的时间(单位:秒)
/// </summary>
/// <returns></returns>
-(long)getElapsedRealtime{
    return [PlatformUtilityManager getElapsedRealtime];
}

- (void)clearAllUserData {
    [PlatformUtilityManager clearAllUserData];
}

- (void)openNativeUrl:(NSString *)url {
    if(url==nil)return;
    NSLog(@"%@ openNativeUrl:%@",TAG,url);
//    url=@"fb://profile/100089857723646";test
    NSURL*nativeUrl = [NSURL URLWithString:url];
    if([[UIApplication sharedApplication]canOpenURL:nativeUrl]){
        [[UIApplication sharedApplication] openURL:nativeUrl];
    }
}

- (float)nativeReadOperate:(NSString *)keyName {
    NSNumber*number =[[NSUserDefaults standardUserDefaults] objectForKey:keyName];
    if(number==nil)
    {
        [PlatformUtilityManager nativeSaveOperate:keyName:0];
        return 0;
    }
    NSLog(@"%@ nativeReadOperate:[%@][%@]",TAG,keyName,number);
    return [number floatValue];
}

- (void)nativeSaveOperate:(NSString *)keyName :(float)value {
    NSNumber*number =[NSNumber numberWithFloat:value];
    [[NSUserDefaults standardUserDefaults] setObject:number forKey:keyName];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"%@ nativeSaveOperate:[%@][%@]",TAG,keyName,number);
}
@end
