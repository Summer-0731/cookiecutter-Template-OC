//
//  PlatformUtilityManager.h
//  IOSUseUnityTest
//
//  Created by mac on 2022/10/19.
//

#ifndef PlatformUtilityManager_h
#define PlatformUtilityManager_h

@interface PlatformUtilityManager : NSObject{
    
}

+(void) clearAllUserData;

/// <summary>
/// 震动
/// </summary>
/// <param name="duration">持续时间</param>
/// <param name="repeat">重复几次pattern,-1表示不重复</param>
+(void) vibrator:(float) duration : (int) repeat;

/// <summary>
/// 获取语言
/// </summary>
/// <returns></returns>
+(NSString*) getLanguageCode;

/// <summary>
/// 获取国家
/// </summary>
/// <returns></returns>
+(NSString*) getRegionCode;

/// <summary>
/// 获取包名
/// </summary>
/// <returns></returns>
+(NSString*) getBundleId;

/// <summary>
/// 获取版本名
/// </summary>
/// <returns></returns>
+(NSString*) getAppVersion;

/// <summary>
/// 获取刘海高度
/// </summary>
/// <returns></returns>
+(int) getNotchHeight;

/// <summary>
/// 应用内评价
/// </summary>
+(void) showReview;

/// <summary>
/// 获取唯一标识符
/// </summary>
/// <returns></returns>
+(NSString*) getUniqueId;

/// <summary>
/// 获取设备Id
/// </summary>
/// <returns></returns>
+(NSString*) getDeviceId;

/// <summary>
/// 获取开机后到此时的时间(单位:秒)
/// </summary>
/// <returns></returns>
+(long)getElapsedRealtime;

+(void)openNativeUrl:(NSString *) url;
+(float)nativeReadOperate:(NSString *) keyName;
+(void)nativeSaveOperate:(NSString *) keyName:(float)value;
@end

#endif /* PlatformUtilityManager_h */
