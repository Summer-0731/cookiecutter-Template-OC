//
//  PlatformUtilityManager.m
//  IOSUseUnityTest
//
//  Created by mac on 2022/10/19.
//

#import <Foundation/Foundation.h>
#import "PlatformUtilityManager.h"
#import "KeyChainManager.h"
#import <AVFoundation/AVFoundation.h>
#import <StoreKit/StoreKit.h>

static NSString* TAG=@"PlatformUtilityManager :";

@implementation PlatformUtilityManager

+(void)clearAllUserData{
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    NSDictionary* dic = [userDefaults dictionaryRepresentation];
    for (id key in dic) {
        [userDefaults removeObjectForKey:key];
    }
}

/// <summary>
/// 震动
/// </summary>
/// <param name="duration">持续时间</param>
/// <param name="repeat">重复几次pattern,-1表示不重复</param>
+(void) vibrator:(float) duration : (int) repeat{
    if (@available(iOS 10.0,*)) {
        UIImpactFeedbackGenerator*impactLight = [[UIImpactFeedbackGenerator alloc]initWithStyle:UIImpactFeedbackStyleLight];
        [impactLight impactOccurred];
    }
    else{
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
}

/// <summary>
/// 获取语言
/// </summary>
/// <returns></returns>
+(NSString*) getLanguageCode{
    NSString *localeLanguage = [NSLocale preferredLanguages][0];
//    NSString *localeLanguage = [[NSLocale currentLocale] localeIdentifier];
    NSLog(@"%@%@%@",TAG,@"localeLanguage:",localeLanguage);
    
    //字符串按照【分隔成数组
    NSArray *array = [localeLanguage componentsSeparatedByString:@"-"];
    NSString* language=(NSString *)array[0];
    NSLog(@"%@%@%@",TAG,@"language:",language);
    return language;
}

/// <summary>
/// 获取国家
/// </summary>
/// <returns></returns>
+(NSString*) getRegionCode{
    // iOS 获取设备当前地区的代码
    NSString *localeIdentifier = [[[NSLocale currentLocale] objectForKey:NSLocaleIdentifier]stringValue];
    NSLog(@"%@%@%@",TAG,@"localeIdentifier:",localeIdentifier);
   
    //字符串按照【分隔成数组
    NSArray *array = [localeIdentifier componentsSeparatedByString:@"_"];
    NSString* identifier =(NSString *)array[1];
    NSLog(@"%@%@%@",TAG,@"identifier:",identifier);
    return identifier;
}

/// <summary>
/// 获取包名
/// </summary>
/// <returns></returns>
+(NSString*) getBundleId{
    NSString *currentVersion = [[NSBundle mainBundle].infoDictionary objectForKey:@"CFBundleIdentifier"];
    return currentVersion;
}

/// <summary>
/// 获取版本名
/// </summary>
/// <returns></returns>
+(NSString*) getAppVersion{
    NSString *currentVersion = [[NSBundle mainBundle].infoDictionary objectForKey:@"CFBundleShortVersionString"];
    return currentVersion;
}

/// <summary>
/// 获取刘海高度
/// </summary>
/// <returns></returns>
+(int) getNotchHeight{
    //判断是否是手机
    if (UIDevice.currentDevice.userInterfaceIdiom != UIUserInterfaceIdiomPhone) {
          return 0;
      }
    if (@available(iOS 11.0, *)) {
        UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
        if (mainWindow.safeAreaInsets.bottom > 0.0) {
            return 88;
        }
    }
    return 0;
}

/// <summary>
/// 应用内评价
/// </summary>
+(void) showReview{
    [SKStoreReviewController requestReview];
}

/// <summary>
/// 获取唯一标识符
/// </summary>
/// <returns></returns>
+(NSString*) getUniqueId{
    NSString* bundleId = [self getBundleId];
    NSString* key = [bundleId stringByAppendingString:@".uuid"];
    NSString *uuid = [KeyChainManager load: key];
    if (!uuid || uuid.length == 0) {
        uuid = [[NSUUID UUID] UUIDString];
        [KeyChainManager save:key data:uuid];
    }
    return uuid;
}

/// <summary>
/// 获取设备Id
/// </summary>
/// <returns></returns>
+(NSString*) getDeviceId{
    NSString* bundleId = [self getBundleId];
    NSString* key = [bundleId stringByAppendingString:@".uuid"];
    NSString *uuid = [KeyChainManager load: key];
    if (!uuid || uuid.length == 0) {
        uuid = [[NSUUID UUID] UUIDString];
        [KeyChainManager save:key data:uuid];
    }
    return uuid;
}

/// <summary>
/// 获取开机后到此时的时间(单位:秒)
/// </summary>
/// <returns></returns>
+(long)getElapsedRealtime{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_nsec;
}

+(void)openNativeUrl:(NSString *)url{
    if(url==nil)return;
    NSLog(@"%@ openNativeUrl:%@",TAG,url);
//    url=@"fb://profile/100089857723646";test
    NSURL*nativeUrl = [NSURL URLWithString:url];
    if([[UIApplication sharedApplication]canOpenURL:nativeUrl]){
        [[UIApplication sharedApplication] openURL:nativeUrl];
    }
}


+(float)nativeReadOperate:(NSString *) keyName{
    NSNumber*number =[[NSUserDefaults standardUserDefaults] objectForKey:keyName];
    if(number==nil)
    {
        [PlatformUtilityManager nativeSaveOperate:keyName:0];
        return 0;
    }
    NSLog(@"%@ nativeReadOperate:[%@][%@]",TAG,keyName,number);
    return [number floatValue];
}

+(void)nativeSaveOperate:(NSString *) keyName:(float)value{
    NSNumber*number =[NSNumber numberWithFloat:value];
    [[NSUserDefaults standardUserDefaults] setObject:number forKey:keyName];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"%@ nativeSaveOperate:[%@][%@]",TAG,keyName,number);
}

@end
