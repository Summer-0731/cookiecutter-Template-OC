//
//  AppDelegate+Utility.h
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate.h"

#import <UnityFramework/PlatformUtilityInvoker.h>
#import "PlatformUtility/PlatformUtilityManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Utility)<IPlatformUtilityInvoker>

-(void)initUtility;

@end

NS_ASSUME_NONNULL_END
