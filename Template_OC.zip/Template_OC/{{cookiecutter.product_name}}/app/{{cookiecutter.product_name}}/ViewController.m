//
//  ViewController.m
//  {{cookiecutter.product_name}}
//
//  Created by Summer on 2023/7/28.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
