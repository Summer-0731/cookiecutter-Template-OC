//
//  FacebookManager.m
//  Unity-iPhone
//
//  Created by apple on 2023/4/4.
//
#import "FacebookManager.h"


static FacebookManager* instance;
static NSString* TAG= @"FacebookManager :";

@implementation FacebookManager
+(FacebookManager *)getInstance{
    if(instance == NULL){
        instance=[FacebookManager alloc];
    }
    return instance;
}

-(void)init:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions withlistener:(id<IFacebookListener>)listener{
    facebookListener = listener;
    [[FBSDKApplicationDelegate sharedInstance] application:application didFinishLaunchingWithOptions:launchOptions];
//    [[FBSDKSettings sharedSettings] enableLoggingBehavior:FBSDKLoggingBehaviorGraphAPIDebugInfo];
//    [[FBSDKSettings sharedSettings] enableLoggingBehavior:FBSDKLoggingBehaviorNetworkRequests];
}

- (BOOL)application:(UIApplication*)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    BOOL handled =[[FBSDKApplicationDelegate sharedInstance] application:application openURL:url options:options];
    return handled;
}

-(void)login:(int)loginType:(UIViewController *)viewcontroller{
    FBSDKAccessToken* accessToken =[FBSDKAccessToken currentAccessToken];
    if(accessToken){
        NSLog(@"%@ login with token,userid:%@,token:%@",TAG,accessToken.userID,accessToken.tokenString);
        NSMutableDictionary* dic = [[NSMutableDictionary alloc]init];
        [dic setObject:@"" forKey:@"errorMsg"];
        [dic setObject:accessToken.userID forKey:@"playerId"];
        [dic setObject:[NSNumber numberWithInteger:loginType] forKey:@"loginType"];
        NSString* unityMsg = [instance toJsonString:dic];
        [facebookListener onLoginResult:unityMsg];
        return;
    }else{
        if(loginType!=1)return;
        FBSDKLoginManager*loginer = [[FBSDKLoginManager alloc] init];
        FBSDKLoginManagerLoginResultBlock completion =^(FBSDKLoginManagerLoginResult * _Nullable result, NSError * _Nullable error) {
        NSMutableDictionary* dic = [[NSMutableDictionary alloc]init];
        if(error){
            NSLog(@"%@ login fail,error:%@",TAG,error);
            [dic setObject:(@"%@",error) forKey:@"errorMsg"];
            [dic setObject:@"" forKey:@"playerId"];
            [dic setObject:[NSNumber numberWithInteger:loginType] forKey:@"loginType"];
            NSString* unityMsg = [instance toJsonString:dic];
            [facebookListener onLoginResult:unityMsg];
            return;
        }
        FBSDKAccessToken* accessToken =[FBSDKAccessToken currentAccessToken];
        if(accessToken){
            NSLog(@"%@ login success,userid:%@,token:%@",TAG,accessToken.userID,accessToken.tokenString);
            [dic setObject:@"" forKey:@"errorMsg"];
            [dic setObject:accessToken.userID forKey:@"playerId"];
            NSString* unityMsg = [instance toJsonString:dic];
            [dic setObject:[NSNumber numberWithInteger:loginType] forKey:@"loginType"];
            [facebookListener onLoginResult:unityMsg];
            return;
        }
        NSLog(@"%@ login cancel",TAG);
        [dic setObject:@"login cancel" forKey:@"errorMsg"];
        [dic setObject:@"" forKey:@"playerId"];
        [dic setObject:[NSNumber numberWithInteger:loginType] forKey:@"loginType"];
        NSString* unityMsg = [instance toJsonString:dic];
        [facebookListener onLoginResult:unityMsg];};
        NSMutableArray* permissionArray=[NSMutableArray arrayWithCapacity:0];
        [permissionArray addObject:@"email"];
        [permissionArray addObject:@"user_friends"];
        FBSDKLoginTracking tracking=FBSDKLoginTrackingEnabled;
    
        [loginer logInFromViewController:viewcontroller configuration:[[FBSDKLoginConfiguration alloc]initWithPermissions:permissionArray tracking:tracking] completion:completion];
    }
}

-(void)logout:(UIViewController *)viewcontroller{
    if([FBSDKAccessToken currentAccessToken]){
        NSLog(@"%@ logining has token,start logout",TAG);
        FBSDKLoginManager* logouter =[[FBSDKLoginManager alloc] init];
        [logouter logOut];
        NSLog(@"%@ logout success",TAG);
        NSMutableDictionary* dic = [[NSMutableDictionary alloc]init];
        [dic setObject:@"" forKey:@"errorMsg"];
        [dic setObject:@"" forKey:@"playerId"];
        NSString* unityMsg = [instance toJsonString:dic];
        [facebookListener onLogoutResult:unityMsg];
    }
}

-(NSString *)toJsonString:(NSMutableDictionary*)dic{
    NSError* error;
    NSData* data = [NSJSONSerialization dataWithJSONObject:dic options:kNilOptions error: &error];
    
    return [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
}
@end
