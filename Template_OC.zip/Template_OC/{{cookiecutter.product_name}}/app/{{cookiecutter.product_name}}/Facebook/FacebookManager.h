//
//  FacebookManager.h
//  Unity-iPhone
//
//  Created by apple on 2023/4/4.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IFacebookListener.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FacebookManager : NSObject{
    id<IFacebookListener> facebookListener;
    bool login;
}
+(FacebookManager*)getInstance;


-(void)init:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions withlistener:(id<IFacebookListener>)listener;
- (BOOL)application:(UIApplication*)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;
-(void)login:(int)loginType:(UIViewController*)viewcontroller;

-(void)logout:(UIViewController*)viewcontroller;

-(NSString*)toJsonString:(NSMutableDictionary*) dic;
@end

NS_ASSUME_NONNULL_END

