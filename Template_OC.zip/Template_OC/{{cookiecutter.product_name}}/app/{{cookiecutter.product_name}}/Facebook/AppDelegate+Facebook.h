//
//  AppDelegate+Facebook.h
//  ExportUnityTest
//
//  Created by Summer on 2023/7/17.
//

#import "AppDelegate.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <UnityFramework/FacebookInvoker.h>
#import "IFacebookListener.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Facebook)<IFacebookInvoker>

- (void)facebookApplication:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions withlistener:(id<IFacebookListener>)listener;

@end

NS_ASSUME_NONNULL_END
