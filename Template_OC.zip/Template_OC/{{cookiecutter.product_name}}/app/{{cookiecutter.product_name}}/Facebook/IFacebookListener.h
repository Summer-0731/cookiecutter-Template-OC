//
//  IFacebookListener.h
//  Unity-iPhone
//
//  Created by apple on 2023/4/4.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@protocol IFacebookListener

-(void) onLoginResult:(NSString*)unityMsg;
-(void) onLogoutResult:(NSString*)unityMsg;

@end

NS_ASSUME_NONNULL_END
