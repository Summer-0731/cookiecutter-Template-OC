//
//  AppDelegate+Purchase.m
//  IOSUseUnity
//
//  Created by Machals on 2023/1/3.
//

#import "AppDelegate+Purchase.h"

static NSString* TAG=@"AppDelegate (Purchase):";

@implementation AppDelegate (Purchase)


#pragma mark - IInAppPurchaseInvoker

-(void)initPurchase{
    [NSClassFromString(@"InAppPurchaseInvoker") registerInAppPurchaseInvoker:self];
    [[InAppPurchaseManager getInstance]init :self :enableLog];
}
/// <summary>
/// 初始化商品
/// </summary>
/// <param name="productJson"></param>
-(void) addProductJson:(NSString*) productJson{
    [[InAppPurchaseManager getInstance]addProductJson:productJson];
}

/// <summary>
/// 购买商品
/// </summary>
/// <param name="productId"></param>
-(void) purchase:(NSString*) productId{
    [[InAppPurchaseManager getInstance]purchase:productId];
}

/// <summary>
/// 恢复已购商品
/// </summary>
-(void) restore{
    [[InAppPurchaseManager getInstance]restore];
}

/// <summary>
/// 是否购买过该商品,卸载重装后,需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isPurchasedProduct:(NSString*) productId{
    return [[InAppPurchaseManager getInstance]isPurchasedProduct:productId];
}
/// <summary>
/// 自动订阅是否有效，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(bool) isAutoSubscriptionAvailable:(NSString*) productId{
    return [[InAppPurchaseManager getInstance]isAutoSubscriptionAvailable:productId];
}
/// <summary>
/// 获取自动订阅剩余天数，卸载重装后，需要restore才能保证数据正确
/// </summary>
/// <param name="productId"></param>
/// <returns></returns>
-(int) getLeftAutoSubscriptionAvailableDay:(NSString*) productId{
    return [[InAppPurchaseManager getInstance]getLeftAutoSubscriptionAvailableDay:productId];
}

#pragma mark - IInAppPurchaseListener
/// <summary>
/// 查询商品详情成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onQueryProductDetailSuccess:(NSString*) returnCode{
    [self UnitySendMessage:"OnQueryProductDetailSuccess":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}
/// <summary>
/// 查询商品详情失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onQueryProductDetailFailed:(NSString*) returnCode{
    [self UnitySendMessage:"OnQueryProductDetailFailed":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}
/// <summary>
/// 商品购买成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onPurchaseSuccess:(NSString*) returnCode{
    NSLog(@"%@%@",TAG,@"onPurchaseSuccess: ");
    [self UnitySendMessage:"OnPurchaseSuccess":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}
/// <summary>
/// 商品购买失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onPurchaseFailed:(NSString*) returnCode{
    [self UnitySendMessage:"OnPurchaseFailed":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}

/// <summary>
/// 商品补发成功回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onReissueProduct:(NSString*) returnCode{
    NSLog(@"%@%@",TAG,@"onReissueProduct: ");
    [self UnitySendMessage:"OnReissueProduct":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}

/// <summary>
/// 商品restore回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestored:(NSString*) returnCode{
    [self UnitySendMessage:"OnProductRestored":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}
/// <summary>
/// 商品restore完毕回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestoredCompleted:(NSString*) returnCode{
    [self UnitySendMessage:"OnProductRestoredCompleted":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}
/// <summary>
/// 商品restore失败回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onProductRestoredError:(NSString*) returnCode{
    [self UnitySendMessage:"OnProductRestoredError":[returnCode cStringUsingEncoding:NSUTF8StringEncoding]];
}



@end
