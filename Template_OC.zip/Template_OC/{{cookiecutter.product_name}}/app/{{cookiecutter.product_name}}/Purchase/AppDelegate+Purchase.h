//
//  AppDelegate+Purchase.h
//  IOSUseUnity
//
//  Created by Machals on 2023/1/3.
//

#import "AppDelegate.h"

#import <UnityFramework/InAppPurchaseInvoker.h>

#import "InAppPurchase/InAppPurchaseListener.h"
#import "InAppPurchase/InAppPurchaseManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (Purchase)<IInAppPurchaseInvoker,IInAppPurchaseListener>

@end

NS_ASSUME_NONNULL_END
