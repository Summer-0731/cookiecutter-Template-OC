//
//  InAppPurchaseError.h
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

@interface InAppPurchaseError : NSObject
{
    
}

@property(nonatomic,retain) NSString* productId;
@property(nonatomic) int errorCode;
@property(nonatomic,retain) NSString* errorMsg;

-(instancetype)init:(NSString*)productId :(int)errorCode :(NSString*)errorMsg;
-(NSString*)toJsonString;

@end
