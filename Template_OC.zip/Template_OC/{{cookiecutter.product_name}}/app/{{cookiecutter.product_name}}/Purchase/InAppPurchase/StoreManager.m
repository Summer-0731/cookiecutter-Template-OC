/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Retrieves product information from the App Store using SKRequestDelegate, SKProductsRequestDelegate, SKProductsResponse, and
 SKProductsRequest. Notifies its observer with a list of products available for sale along with a list of invalid product identifiers. Logs an error
 message if the product request failed.
*/

#import "StoreManager.h"
#import "InAppPurchaseManager.h"
#import "StoreData.h"
#import "PlatformProducts.h"
#import "PlatformProductDetails.h"

NSString *const PCSProductsAvailableProducts = @"Available Products";
NSString *const PCSProductsInvalidIdentifiers = @"Invalid Product Identifiers";

@interface StoreManager()<SKRequestDelegate, SKProductsRequestDelegate>
@end

@implementation StoreManager

+ (StoreManager *)sharedInstance {
    static dispatch_once_t onceToken;
    static StoreManager * storeManagerSharedInstance;
    
    dispatch_once(&onceToken, ^{
        storeManagerSharedInstance = [[StoreManager alloc] init];
    });
    return storeManagerSharedInstance;
}

- (instancetype)init {
    self = [super init];
    
    if (self != nil) {
        _hasLoadedProducts=false;
        _availableProductDetailDic = [[NSMutableDictionary alloc]initWithCapacity:0];
        _invalidProductIdentifiers = [[NSMutableArray alloc] initWithCapacity:0];
        
    }
    return self;
}

/// <summary>
/// 初始化商品
/// </summary>
/// <param name="productJson"></param>
-(void) addProductJson:(NSString*) productJson{
    PlatformProducts* platformProducts = [[PlatformProducts alloc]initWithJsonStr:productJson];
    
    for (PlatformProduct* platformProduct in platformProducts.products) {
        if([self.productTypes objectForKey:platformProduct.productId]==nil){
            [self.productTypes setObject:[NSNumber numberWithInt: platformProduct.productType] forKey:platformProduct.productId];
        }
    }
    
    NSSet *productIdentifiers = [NSSet setWithArray:platformProducts.productIds];
    
    // Initialize the product request with the above identifiers.
    self.productRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:productIdentifiers];
    self.productRequest.delegate = self;
    
    [self fetchProductsMatchingIdentifiers];
    [self postTime];
}

#pragma mark - Request Information


//向服务器请求商品信息
/// Fetches information about your products from the App Store.
-(void)fetchProductsMatchingIdentifiers{
    // Send the request to the App Store.
    [self.productRequest start];
}

//商品信息请求回调
/// Used to get the App Store's response to your request and notify your observer.
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    
    //保存可用的商品
    // products contains products whose identifiers have been recognized by the App Store. As such, they can be purchased.
    if ((response.products).count > 0) {
        for (SKProduct* productDetail in response.products) {
            [self.availableProductDetailDic setObject:productDetail forKey:productDetail.productIdentifier];
        }
    }
    
    //设置自动订阅信息
    for (SKProduct* product in self.availableProductDetailDic.allValues) {
        [StoreData setAutoSubscriptionInfo:product withIdentifier:product.productIdentifier];
    }
    
    //保存不可用的商品id
    if ((response.invalidProductIdentifiers).count > 0) {
        self.invalidProductIdentifiers = [NSMutableArray arrayWithArray:response.invalidProductIdentifiers];
    }
    
    self.hasLoadedProducts=true;
    
    PlatformProductDetails * productDetails = [[PlatformProductDetails alloc]init];
    
    [[InAppPurchaseManager getInstance]onQueryProductDetailSuccess:productDetails];
    
}

//请求商品信息失败
/// Called when the product request failed.
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    self.message = error.localizedDescription;
    [self fetchProductsMatchingIdentifiers];
}


//获取商品信息
-(SKProduct*)getProduct:(NSString *)productId{
    return [self.availableProductDetailDic objectForKey:productId];
}

//请求时间
- (void)postTime
{
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://ih5.glorygame.cn/ctime"]];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-type"];
    request.HTTPMethod = @"POST";
    
    NSOperationQueue* backgroundQueue = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request queue:backgroundQueue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (connectionError) {
            NSLog(@"post data request error!");
        }
        else{
            NSString * timeIntervalStr  =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSTimeInterval timeInterval = [timeIntervalStr doubleValue];
            NSDate* date = [[NSDate alloc]initWithTimeIntervalSince1970:timeInterval];
            [StoreData setDate:date];
        }
        
    }];
}

@end
