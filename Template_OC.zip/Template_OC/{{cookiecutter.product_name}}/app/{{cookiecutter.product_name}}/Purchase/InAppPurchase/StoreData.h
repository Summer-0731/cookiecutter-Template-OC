//
//  StoreData.h
//  SdkSample
//
//  Created by Yanxi on 2020/11/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>


NS_ASSUME_NONNULL_BEGIN

//记录一些已购信息
@interface StoreData : NSObject

+(NSDate*)date;
//设置时间
+(void)setDate:(NSDate*)date;

//设置自动订阅周期信息
+(void) setAutoSubscriptionInfo:(SKProduct*)product withIdentifier:(NSString*)identifier;

//购买物品后
+(void) handlePurchasedTransaction:(SKPaymentTransaction*)transaction;
//恢复该商品
+(void) handleRestoredTransaction:(SKPaymentTransaction*)transaction;
//是否购买过该商品
+(bool) isPurchasedProduct:(NSString*)identifier;
//自动订阅是否在日期内
+(bool) isAutoSubscriptionAvailable:(NSString*)identifier;
//获取自动订阅剩余天数
+(int) getLeftAutoSubscriptionAvailableDay:(NSString*)identifier;


@end

NS_ASSUME_NONNULL_END
