//
//  InAppPurchaseError.m
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

#import <Foundation/Foundation.h>
#import "InAppPurchaseError.h"

@implementation InAppPurchaseError

-(instancetype)init:(NSString*)productId:(int)errorCode:(NSString*)errorMsg{
    self.productId = productId;
    self.errorCode =errorCode;
    self.errorMsg=errorMsg;
    return self;
}

-(NSString*)toJsonString{
    NSMutableDictionary* dic = [[NSMutableDictionary alloc]init];
    [dic setObject:self.productId forKey:@"productId"];
    [dic setObject:[NSNumber numberWithInt: self.errorCode] forKey:@"errorCode"];
    [dic setObject:self.errorMsg forKey:@"errorMsg"];
    
    NSError* error;
    NSData* data = [NSJSONSerialization dataWithJSONObject:dic options:kNilOptions error: &error];
    
    return [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
}

@end
