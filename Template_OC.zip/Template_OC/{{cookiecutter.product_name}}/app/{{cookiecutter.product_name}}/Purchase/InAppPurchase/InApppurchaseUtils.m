//
//  InApppurchaseUtils.m
//  IOSUseUnityProject
//
//  Created by mac on 2022/11/1.
//

#import <Foundation/Foundation.h>
#import "InApppurchaseUtils.h"
#import "InAppPurchaseErrorCode.h"

//typedef NS_ENUM(NSInteger,SKErrorCode) {
//    SKErrorUnknown,
//    SKErrorClientInvalid,                                                                                       // client is not allowed to issue the request, etc.
//    SKErrorPaymentCancelled,                                                                                    // user cancelled the request, etc.
//    SKErrorPaymentInvalid,                                                                                      // purchase identifier was invalid, etc.
//    SKErrorPaymentNotAllowed,                                                                                   // this device is not allowed to make the payment
//    SKErrorStoreProductNotAvailable API_AVAILABLE(ios(3.0), macos(10.15), watchos(6.2)),                        // Product is not available in the current storefront
//    SKErrorCloudServicePermissionDenied API_AVAILABLE(ios(9.3), tvos(9.3), watchos(6.2), macos(11.0)),          // user has not allowed access to cloud service information
//    SKErrorCloudServiceNetworkConnectionFailed API_AVAILABLE(ios(9.3), tvos(9.3), watchos(6.2), macos(11.0)),   // the device could not connect to the nework
//    SKErrorCloudServiceRevoked API_AVAILABLE(ios(10.3), tvos(10.3), watchos(6.2), macos(11.0)),                 // user has revoked permission to use this cloud service
//    SKErrorPrivacyAcknowledgementRequired API_AVAILABLE(ios(12.2), tvos(12.2), macos(10.14.4), watchos(6.2)),   // The user needs to acknowledge Apple's privacy policy
//    SKErrorUnauthorizedRequestData API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),                      // The app is attempting to use SKPayment's requestData property, but does not have the appropriate entitlement
//    SKErrorInvalidOfferIdentifier API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),                       // The specified subscription offer identifier is not valid
//    SKErrorInvalidSignature API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),                             // The cryptographic signature provided is not valid
//    SKErrorMissingOfferParams API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),                           // One or more parameters from SKPaymentDiscount is missing
//    SKErrorInvalidOfferPrice API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),                            // The price of the selected offer is not valid (e.g. lower than the current base subscription price)
//    SKErrorOverlayCancelled API_AVAILABLE(ios(12.2), macos(10.14.4), watchos(6.2)),
//    SKErrorOverlayInvalidConfiguration API_AVAILABLE(ios(14.0)) API_UNAVAILABLE(macos, watchos) __TVOS_PROHIBITED,
//    SKErrorOverlayTimeout API_AVAILABLE(ios(14.0)) API_UNAVAILABLE(macos, watchos) __TVOS_PROHIBITED,
//    SKErrorIneligibleForOffer API_AVAILABLE(ios(14.0), macos(11.0), watchos(7.0)),                              // User is not eligible for the subscription offer
//    SKErrorUnsupportedPlatform API_AVAILABLE(ios(14.0), macos(11.0), watchos(7.0)) __TVOS_PROHIBITED,
//    SKErrorOverlayPresentedInBackgroundScene API_AVAILABLE(ios(14.5)) API_UNAVAILABLE(macos, watchos) __TVOS_PROHIBITED  // Client tried to present an SKOverlay in UIWindowScene not in the foreground
//}

@implementation InApppurchaseUtils

+(int)convertResponseCodeToErrorCode:(int)responseCode{
//
//        switch (responseCode){
//            case BillingClient.BillingResponseCode.SERVICE_TIMEOUT:
//                return InAppPurchaseErrorCodeSERVICE_TIMEOUT;
//            case BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED:
//                return InAppPurchaseErrorCodeFEATURE_NOT_SUPPORTED;
//            case BillingClient.BillingResponseCode.SERVICE_DISCONNECTED:
//                return InAppPurchaseErrorCodeSERVICE_DISCONNECTED;
//            case BillingClient.BillingResponseCode.OK:
//                return InAppPurchaseErrorCodeOK;
//            case SKErrorPaymentCancelled:
//                return InAppPurchaseErrorCodeUSER_CANCELED;
//            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE:
//                return InAppPurchaseErrorCodeSERVICE_UNAVAILABLE;
//            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE:
//                return InAppPurchaseErrorCodeBILLING_UNAVAILABLE;
//            case BillingClient.BillingResponseCode.ITEM_UNAVAILABLE:
//                return InAppPurchaseErrorCodeITEM_UNAVAILABLE;
//            case BillingClient.BillingResponseCode.DEVELOPER_ERROR:
//                return InAppPurchaseErrorCodeDEVELOPER_ERROR;
//            case BillingClient.BillingResponseCode.ERROR:
//                return InAppPurchaseErrorCodeERROR;
//            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED:
//                return InAppPurchaseErrorCodeITEM_ALREADY_OWNED;
//            case BillingClient.BillingResponseCode.ITEM_NOT_OWNED:
//                return InAppPurchaseErrorCodeITEM_NOT_OWNED;
//            default:
//                return InAppPurchaseErrorCodeUNKNOWN;
//        }
    return InAppPurchaseErrorCodeUNKNOWN;
}

+(NSString*) getErrorCodeMsg:(int)errorCode{
    switch (errorCode) {
        case  InAppPurchaseErrorCodeOK:
            return @"Success";
        case InAppPurchaseErrorCodeBILLING_UNAVAILABLE:
            return @"Billing API version is not supported for the type requested.";
        case InAppPurchaseErrorCodeFEATURE_NOT_SUPPORTED:
            return @"Requested feature is not supported by Play Store on the current device.";
        case InAppPurchaseErrorCodeSERVICE_DISCONNECTED:
            return @"Play Store service is not connected now - potentially transient state.";
        case InAppPurchaseErrorCodeSERVICE_UNAVAILABLE:
            return @"Network connection is down.";
        case InAppPurchaseErrorCodeSERVICE_TIMEOUT:
            return @"The request has reached the maximum timeout before Google Play responds.";
        case InAppPurchaseErrorCodeITEM_UNAVAILABLE:
            return @"Requested product is not available for purchase.";
        case InAppPurchaseErrorCodeITEM_NOT_OWNED:
            return @"Failure to consume since item is not owned.";
        case InAppPurchaseErrorCodeITEM_ALREADY_OWNED:
            return @"Failure to purchase since item is already owned.";
        case InAppPurchaseErrorCodeITEM_ALREADY_REWARDED:
            return @"Product has already rewarded.";
        case InAppPurchaseErrorCodeLAUNCH_FLOW_FAIL:
            return @"Launch flow failed";
        case InAppPurchaseErrorCodeUSER_CANCELED:
            return @"User pressed back or canceled a dialog.";
        case InAppPurchaseErrorCodeDEVELOPER_ERROR:
            return @"Invalid arguments provided to the API.";
        case InAppPurchaseErrorCodeERROR:
            return @"Fatal error during the API action.";
        default:
            return @"Unknown error";
    }
}



@end
