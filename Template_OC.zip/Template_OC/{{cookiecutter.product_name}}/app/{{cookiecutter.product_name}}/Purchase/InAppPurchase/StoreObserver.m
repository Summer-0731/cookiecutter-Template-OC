/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implements the SKPaymentTransactionObserver protocol. Handles purchasing and restoring products using paymentQueue:updatedTransactions: .
*/

#import "StoreObserver.h"
#import "InAppPurchaseManager.h"
#import "StoreManager.h"
#import "StoreData.h"
#import "InAppPurchaseError.h"

static NSString* TAG=@"StoreObserver";

@implementation StoreObserver
+ (StoreObserver *)sharedInstance {
    static dispatch_once_t onceToken;
    static StoreObserver * storeObserverSharedInstance;
    
    dispatch_once(&onceToken, ^{
        storeObserverSharedInstance = [[StoreObserver alloc] init];
    });
    return storeObserverSharedInstance;
}

- (instancetype)init {
    self = [super init];
    
    if (self != nil) {
        _productsPurchased = [[NSMutableArray alloc] initWithCapacity:0];
        _productsRestored = [[NSMutableArray alloc] initWithCapacity:0];

    }
    return self;
}
/**
    Indicates whether the user is allowed to make payments.
    - returns: true if the user is allowed to make payments and false, otherwise. Tell StoreManager to query the App Store when the user is allowed to make payments and there are product identifiers to be
     queried.
 */

-(BOOL)isAuthorizedForPayments {
    return [SKPaymentQueue canMakePayments];
}

#pragma mark - Submit Payment Request

/// Creates and adds a payment request to the payment queue.
-(void)buy:(SKProduct *)product {
    SKMutablePayment *payment = [SKMutablePayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark - Restore All Restorable Purchases

/// Restores all previously completed purchases.
-(void)restore {
    if (self.productsRestored.count > 0) {
        [self.productsRestored removeAllObjects];
    }
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

-(bool)isPurchasedProduct:(NSString *)identifier{
    if([self.productsPurchased count]>0){
        for (SKPaymentTransaction* paymentTransaction in self.productsPurchased) {
            if ([paymentTransaction.payment.productIdentifier isEqualToString:identifier]) {
                return true;
            }
        }
    }
    if([self.productsRestored count]>0){
        for (SKPaymentTransaction* paymentTransaction in self.productsRestored) {
            if([paymentTransaction.payment.productIdentifier isEqualToString:identifier]){
                return true;
            }
        }
    }
    return false;
}

#pragma mark - SKPaymentTransactionObserver Methods

//更新订单信息
/// Called when there are transactions in the payment queue.
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
    for(SKPaymentTransaction *transaction in transactions) {
        switch (transaction.transactionState) {
                //正在交易
            case SKPaymentTransactionStatePurchasing:
                break;
            // Do not block your UI. Allow the user to continue using your app.
                //事物在队列中，但是最终状态由外部操作挂起
            case SKPaymentTransactionStateDeferred:
                NSLog(@"%@:paymentQueue:updatedTransactions SKPaymentTransactionStateDeferred",TAG);
                break;
                //购买成功，客户端已完成交易
            case SKPaymentTransactionStatePurchased:
                //订阅特殊处理（只有retore成功的订单，此值才不为空，TODO是不是自动订阅，第二次到期时也会走此方法）
                if(transaction.originalTransaction){
                     //自动续费的订单,重复购买非消耗行商品
                    [self handleRestoredTransaction:transaction];
                }else{
                     //普通购买，以及第一次购买自动订阅
                    [self handlePurchasedTransaction:transaction];
                }
                break;
                //购买失败
            case SKPaymentTransactionStateFailed:
                [self handleFailedTransaction:transaction];
                break;
                //restroe成功
            case SKPaymentTransactionStateRestored:
                [self handleRestoredTransaction:transaction];
                break;
            default: break;
        }
    }
}

/// Logs all transactions that have been removed from the payment queue.
- (void)paymentQueue:(SKPaymentQueue *)queue removedTransactions:(NSArray *)transactions {
    for(SKPaymentTransaction *transaction in transactions) {
        NSLog(@"%@:paymentQueue:removedTransactions productIdentifier is: %@", TAG, transaction.payment.productIdentifier);
    }
}

//retore失败
/// Called when an error occur while restoring purchases. Notifies the user about the error.
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error {
    NSLog(@"%@:paymentQueue:restoreCompletedTransactionsFailedWithError localizedDescription is : %@",TAG,error.localizedDescription);
    if (error.code != SKErrorPaymentCancelled) {
        self.message = error.localizedDescription;
    }
    
    InAppPurchaseError* purchaseError = [[InAppPurchaseError alloc]init:@"" :error.code :error.localizedDescription];
    [[InAppPurchaseManager getInstance]onProductRestoredError:purchaseError];
    
}

//restore结束
/// Called when all restorable transactions have been processed by the payment queue.
-(void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue {
    [[InAppPurchaseManager getInstance]onProductRestoredCompleted];
}

#pragma mark - Handle Payment Transactions

/// Handles successful purchase transactions.
-(void)handlePurchasedTransaction:(SKPaymentTransaction*)transaction {
    [self.productsPurchased addObject:transaction];
    NSLog(@"%@:handlePurchasedTransaction transactionIdentifier is: %@",TAG,transaction.transactionIdentifier);
    NSLog(@"%@:handlePurchasedTransaction productIdentifier is: %@",TAG,transaction.payment.productIdentifier);
    
    // Finish the successful transaction.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    [StoreData handlePurchasedTransaction:transaction];
    
    [[InAppPurchaseManager getInstance]onPurchaseSuccess:transaction.payment.productIdentifier:transaction.transactionIdentifier];
}

/// Handles failed purchase transactions.
-(void)handleFailedTransaction:(SKPaymentTransaction*)transaction {
    // Finish the failed transaction.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    InAppPurchaseError* purchaseError;
    if(transaction.error){
        purchaseError = [[InAppPurchaseError alloc]init:@"" :transaction.error.code :transaction.error.localizedDescription];
    }
    else{
        purchaseError = [[InAppPurchaseError alloc]init:@"" :transaction.error.code :@""];
    }
    [[InAppPurchaseManager getInstance]onPurchaseFailed:purchaseError];
}

/// Handles restored purchase transactions.
-(void)handleRestoredTransaction:(SKPaymentTransaction*)transaction {
    NSLog(@"%@:handleRestoredTransaction productIdentifier is: %@",TAG,transaction.payment.productIdentifier);
    
    [self.productsRestored addObject:transaction];
    
    // Finish the restored transaction.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    [StoreData handleRestoredTransaction:transaction];
    
    [[InAppPurchaseManager getInstance]onProductRestored:transaction.payment.productIdentifier];
    
}


///// 验证购买凭据
///// @param ProductID 商品ID
//- (void)verifyPruchaseWithID:(NSString *)ProductID
//{
//    // 验证凭据，获取到苹果返回的交易凭据
//    // appStoreReceiptURL iOS7.0增加的，购买交易完成后，会将凭据存放在该地址
//    NSURL *receiptURL = [[NSBundle mainBundle] appStoreReceiptURL];
//    // 从沙盒中获取到购买凭据
//    NSData *receiptData = [NSData dataWithContentsOfURL:receiptURL];
//
//    // 发送网络POST请求，对购买凭据进行验证
//    //In the test environment, use https://sandbox.itunes.apple.com/verifyReceipt
//    //In the real environment, use https://buy.itunes.apple.com/verifyReceipt
//
//    NSString* checkURL=@"https://sandbox.itunes.apple.com/verifyReceipt";
//
//
//    // Create a POST request with the receipt data.
//    NSURL *url = [NSURL URLWithString:checkURL];
//    NSLog(@"checkURL:%@",checkURL);
//
//
//    // 国内访问苹果服务器比较慢，timeoutInterval需要长一点
//    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0f];
//    request.HTTPMethod = @"POST";
//    NSString *encodeStr = [receiptData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
//    NSString *payload = [NSString stringWithFormat:@"{\"receipt-data\" : \"%@\"}", encodeStr];
//    NSData *payloadData = [payload dataUsingEncoding:NSUTF8StringEncoding];
//    request.HTTPBody = payloadData;
//
//    // 提交验证请求，并获得官方的验证JSON结果
//    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
//        NSData *result = data;
//        // 官方验证结果为空
//        if (result == nil) {
//            //NSLog(@"验证失败");
//            //验证失败,通知代理
//
//            NSLog(@"%@,result == nil",TAG);
//        }
//
//        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:result
//                                                             options:NSJSONReadingAllowFragments error:nil];
//        //NSLog(@"RecivedVerifyPruchaseDict：%@", dict);
//        if (dict != nil) {
//            // 验证成功,通知代理
//            NSLog(@"%@,dict != nil",TAG);
//        } else {
//            //验证失败,通知代理
//            NSLog(@"%@,dict == nil",TAG);
//        }
//    }] resume];
//}



@end
