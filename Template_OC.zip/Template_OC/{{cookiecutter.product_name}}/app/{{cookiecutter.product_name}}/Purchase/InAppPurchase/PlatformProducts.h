//
//  PlatformProductDetails.h
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

@interface PlatformProducts : NSObject
{
    
}
@property(nonatomic,retain) NSArray* products;
@property(nonatomic,retain) NSArray* productIds;

-(instancetype)initWithJsonStr:(NSString*) jsonStr;

@end

@interface PlatformProduct : NSObject

@property(nonatomic,retain) NSString* productId;
@property(nonatomic) int productType;

-(instancetype)init:(NSString*)productId:(int)productType;

@end

