//
//  PlatformProductDetails.m
//  IOSUseUnityProject
//
//  Created by mac on 2022/10/31.
//

#import <Foundation/Foundation.h>
#import "PlatformProducts.h"

@implementation PlatformProducts

-(instancetype)initWithJsonStr:(NSString *)jsonStr{
    NSDate* data = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError* error;
    
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    
    NSDictionary* dic = (NSDictionary*)jsonObject;
    NSArray* arr = [dic objectForKey:@"products"];
    
    NSMutableArray* mutableProductArray = [[NSMutableArray alloc]init];
    NSMutableArray* mutableIdArray = [[NSMutableArray alloc]init];
    
    for (int i = 0; i<arr.count; i++) {
        NSDictionary* productDic = [arr objectAtIndex:i];
        PlatformProduct* platformProduct = [[PlatformProduct alloc]init];
        platformProduct.productId=[productDic objectForKey:@"productId"];
        platformProduct.productType=[[productDic objectForKey:@"productType"] intValue];
        [mutableProductArray addObject:platformProduct];
        [mutableIdArray addObject:platformProduct.productId];
    }
    self.products = [NSArray arrayWithArray:mutableProductArray];
    self.productIds=[NSArray arrayWithArray:mutableIdArray];
    
    return self;
}

@end

@implementation PlatformProduct

-(instancetype)init:(NSString *)productId :(int)productType{
    self.productId=productId;
    self.productType=productType;
    return self;
}

@end
