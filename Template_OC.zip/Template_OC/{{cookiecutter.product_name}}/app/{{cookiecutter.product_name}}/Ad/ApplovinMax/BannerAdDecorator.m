//
//  BannerAdDecorator.m
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BannerAdDecorator.h"
#import "AdType.h"

@implementation BannerAdDecorator

-(instancetype)init:(NSString *)adUitId withAdStateListener:(id<IAdStateListener>)iAdStateListener{
    if(self = [super init:adUitId withAdStateListener:iAdStateListener]){
        adView = [[MAAdView alloc]initWithAdUnitIdentifier:adUitId];
        adView.delegate = self;
        UIWindow* uiWindow =[UIApplication sharedApplication].windows[0];

        adView.backgroundColor = uiWindow.backgroundColor;

        [uiWindow addSubview:adView];

        //调整位置跟大小
        adView.translatesAutoresizingMaskIntoConstraints = NO;
        // Anchor the banner to the left, right, and top of the screen.
        [[adView.leadingAnchor constraintEqualToAnchor: uiWindow.leadingAnchor] setActive: YES];
        [[adView.trailingAnchor constraintEqualToAnchor: uiWindow.trailingAnchor] setActive: YES];
        [[adView.bottomAnchor constraintEqualToAnchor: uiWindow.bottomAnchor] setActive: YES];
        
        [[adView.widthAnchor constraintEqualToAnchor: uiWindow.widthAnchor] setActive: YES];
        [[adView.heightAnchor constraintEqualToConstant: UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad ? 90 : 50 ] setActive: YES];
        
        
        adView.hidden = YES;
        [self load];
    }
    return self;
}

-(NSString*)getAdType{
    return AdType.bannerType;
}

-(void)load{
    [adStateListener loadAd:self.getAdType adUnitIdIs:adUnitId];
    [adView loadAd];
}

-(bool)isNeedRetry{
    return false;
}

-(void)didLoadAd:(MAAd *)ad{
    [super didLoadAd:ad];
}

-(void)show:(NSString*)placement{
    self->placement=placement;
    adView.hidden = NO;
    [adView startAutoRefresh];
}

-(void)hide{
    adView.hidden = YES;
    [adView stopAutoRefresh];
}

-(void)didHideAd:(MAAd *)ad{
    [adStateListener onAdHidden:self.getAdType adUnitIdIs:ad.adUnitIdentifier isWatchCompleted:true];
    [super didHideAd:ad];
}

-(bool)isReady{
    return true;
}

- (void)didExpandAd:(MAAd *)ad{
    
}

- (void)didCollapseAd:(MAAd *)ad{
    
}

@end
