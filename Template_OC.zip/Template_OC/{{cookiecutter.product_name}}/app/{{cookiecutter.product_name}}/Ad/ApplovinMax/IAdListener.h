//
//  IAdListener.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol IAdListener
//Banner广告加载状态,true为成功,false为失败
-(void) onBannerAdLoadState:(bool) isSuccess;
//插屏广告加载状态,true为成功,false为失败
-(void)  onInterstitialAdLoadState:(bool) isSuccess;
//视频广告加载状态,true为成功,false为失败
-(void)  onRewardedAdLoadState:(bool) isSuccess;

//插屏展示成功
-(void)  onInterstitialAdDisplay;
//关闭插屏
-(void)  onInterstitialAdHidden;
//视频展示成功
-(void)  onRewardedAdDisplay;
//视频播放完
-(void)  onRewardedAdComplete;
//关闭视频,true为看完广告,false是中途关闭
-(void)  onRewardedAdHidden:(bool) isWatchCompleted;
//视频发放奖励
-(void)  onUserRewarded;
@end

NS_ASSUME_NONNULL_END
