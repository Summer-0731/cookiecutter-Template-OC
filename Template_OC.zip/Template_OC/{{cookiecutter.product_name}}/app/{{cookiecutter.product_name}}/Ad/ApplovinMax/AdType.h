//
//  AdType.h
//  SdkSample
//
//  Created by mac on 2020/5/28.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AdType : NSObject

+(NSString*)bannerType;
+(NSString*)interstitialType;
+(NSString*)rewardedType;

@end

NS_ASSUME_NONNULL_END
