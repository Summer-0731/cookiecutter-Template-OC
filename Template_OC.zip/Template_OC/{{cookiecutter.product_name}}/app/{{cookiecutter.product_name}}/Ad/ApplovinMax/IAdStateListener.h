//
//  IAdStateListener.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol IAdStateListener

@required
-(void)onAdCreated:(NSString*)adType adUnitIdIs:(NSString*)adUnitId;
-(void)loadAd:(NSString*)adType adUnitIdIs:(NSString*)adUnitId;
-(void)onAdLoaded:(NSString*)adType adUnitIdIs:(NSString*)adUnitId;
-(void)onAdLoadFailed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId errorCodeIs:(int)errorCode;
-(void)onAdDisplayed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId adPlacemnt:(NSString*)placement;
-(void)onAdDisplayFailed:(NSString*)adType adUnitIdIs:(NSString*)adUnitId errorCodeIs:(int)errorCode;
-(void)onAdHidden:(NSString*)adType adUnitIdIs:(NSString*)adUnitId isWatchCompleted:(bool)isWatchCompleted;
-(void)onAdClicked:(NSString*)adType adUnitIdIs:(NSString*)adUnitId;

-(void)onRewardedAdStart:(NSString*)adUnitId;
-(void)onRewardedAdComplete:(NSString*)adUnitId;
-(void)onRewardedAdReward:(NSString*)adUnitId;

@end

NS_ASSUME_NONNULL_END
