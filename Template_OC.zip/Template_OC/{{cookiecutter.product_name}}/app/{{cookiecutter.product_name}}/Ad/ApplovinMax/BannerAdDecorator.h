//
//  BannerAdDecorator.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdDecorator.h"
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface BannerAdDecorator : AdDecorator<MAAdViewAdDelegate>{
    MAAdView* adView;
}

-(void)show:(NSString*)placement;
-(void)hide;

@end

NS_ASSUME_NONNULL_END
