//
//  ITrackEventListener.h
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol IAdLogEventListenter

@required
-(void)logAdEvent:(NSString*)eventName withJson:(NSString*) jsonStr;
@end

NS_ASSUME_NONNULL_END
