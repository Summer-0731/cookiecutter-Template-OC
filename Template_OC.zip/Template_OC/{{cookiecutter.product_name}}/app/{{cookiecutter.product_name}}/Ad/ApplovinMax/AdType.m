//
//  AdType.m
//  SdkSample
//
//  Created by mac on 2020/5/28.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AdType.h"

static NSString* const bannerAd = @"BannerAd";
static NSString* const interstitialAd = @"InterstitialAd";
static NSString* const rewardedAd = @"RewardedAd";

@implementation AdType

+(NSString*)bannerType{
    return bannerAd;
}
+(NSString*)interstitialType{
    return interstitialAd;
}
+(NSString*)rewardedType{
    return rewardedAd;
}

@end
