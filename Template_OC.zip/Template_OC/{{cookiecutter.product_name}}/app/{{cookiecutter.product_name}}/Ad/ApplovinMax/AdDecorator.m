//
//  AdDecorator.m
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AdDecorator.h"

@implementation AdDecorator

-(instancetype)init:(NSString*) unitId withAdStateListener:(id<IAdStateListener>) iAdStateListener{
    adUnitId = unitId;
    adStateListener = iAdStateListener;
    [adStateListener onAdCreated:self.getAdType adUnitIdIs:unitId];
    return self;
}

-(void) delayLoad:(long) millis{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, millis), dispatch_get_main_queue(), ^{
        [self load];
       });
}

- (void)didLoadAd:(MAAd *)ad{
    [adStateListener onAdLoaded:self.getAdType adUnitIdIs: ad.adUnitIdentifier];
    retryAttempt=0;
}

- (void)didFailToLoadAdForAdUnitIdentifier:(NSString *)adUnitIdentifier withErrorCode:(NSInteger)errorCode{
    [adStateListener onAdLoadFailed:self.getAdType adUnitIdIs:adUnitIdentifier errorCodeIs:errorCode];
    if(self.isNeedRetry){
        retryAttempt++;
        if(retryAttempt>4){
            retryAttempt =1;
        }
        long delayMillis = pow(2, retryAttempt)*NSEC_PER_SEC;
        [self delayLoad : delayMillis];
    }
}
- (void)didDisplayAd:(MAAd *)ad{
    [adStateListener onAdDisplayed:self.getAdType adUnitIdIs:ad.adUnitIdentifier adPlacemnt:placement];
}
- (void)didFailToDisplayAd:(MAAd *)ad withErrorCode:(NSInteger)errorCode{
    [adStateListener onAdDisplayFailed:self.getAdType adUnitIdIs:ad.adUnitIdentifier errorCodeIs:errorCode];
    [self load];
}
- (void)didHideAd:(MAAd *)ad{
    [self load];
}
- (void)didClickAd:(MAAd *)ad{
    [adStateListener onAdClicked:self.getAdType adUnitIdIs:ad.adUnitIdentifier];
}


@end
