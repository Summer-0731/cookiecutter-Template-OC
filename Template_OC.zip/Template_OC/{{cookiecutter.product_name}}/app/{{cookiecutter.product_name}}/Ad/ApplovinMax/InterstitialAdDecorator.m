//
//  InterstitialAdDecorator.m
//  SdkSample
//
//  Created by mac on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "InterstitialAdDecorator.h"
#import "AdDecorator.h"
#import "AdType.h"

@implementation InterstitialAdDecorator

-(instancetype)init:(NSString *)unitId withAdStateListener:(id<IAdStateListener>)iAdStateListener{
    if(self = [super init:unitId withAdStateListener:iAdStateListener]){
        interstitialAd= [[MAInterstitialAd alloc] initWithAdUnitIdentifier:adUnitId];
        interstitialAd.delegate = self;
        [self load];
    }
    return self;
}
-(NSString*)getAdType{
    return AdType.interstitialType;
}

-(void)load{
    [adStateListener loadAd:self.getAdType adUnitIdIs:adUnitId];
    [interstitialAd loadAd];
}

-(bool)isNeedRetry{
    return true;
}

-(bool)isReady{
    return interstitialAd.isReady;
}

-(void) show:(NSString*)placement{
    self->placement=placement;
    if(self.isReady){
        [interstitialAd showAd];
    }
}

-(void)didHideAd:(MAAd *)ad{
    [adStateListener onAdHidden:self.getAdType adUnitIdIs:ad.adUnitIdentifier isWatchCompleted:true];
    [super didHideAd:ad];
}

@end
