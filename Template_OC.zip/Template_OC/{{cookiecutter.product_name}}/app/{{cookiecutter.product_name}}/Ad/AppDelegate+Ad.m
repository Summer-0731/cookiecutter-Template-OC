//
//  AppDelegate+Ad.m
//  IOSUseUnity
//
//  Created by Machals on 2022/12/30.
//

#import "AppDelegate+Ad.h"

static NSString* TAG=@"AppDelegate (Ad):";

@implementation AppDelegate (Ad)



#pragma mark - Ad

-(void)initAd{
    [NSClassFromString(@"AdInvoker") registerAdInvoker:self];
    [[AdManager getInstance] init:self :NO :self];
}

#pragma mark - AdInvoker

/// <summary>
/// 设置广告UserId
/// </summary>
/// <param name="userId"></param>
- (void)setAdUserId:(NSString *)userId {
    [[AdManager getInstance]setUserIdentifier:userId];
}

/// <summary>
/// 展示插屏
/// </summary>
-(void) showBannerAd:(NSString *) placement{
    [[AdManager getInstance] showBannerAd:placement];
}

/// <summary>
/// 隐藏差评
/// </summary>
-(void) hideBannerAd{
    [[AdManager getInstance]hideBannerAd];
}

/// <summary>
/// 插屏是否就绪
/// </summary>
/// <returns></returns>
-(bool) isInterstitialAdReady{
    NSLog(@"%@%@%d",TAG,@"isInterstitialAdReady: ",[[AdManager getInstance]isInterstitialAdReady]);
    return [[AdManager getInstance]isInterstitialAdReady];
}

/// <summary>
/// 展示插屏
/// </summary>
-(void) showInterstitialAd:(NSString *) placement{
    NSLog(@"%@%@",TAG,@"showInterstitialAd: ");
    [[AdManager getInstance]showInterstitialAd:placement];
}

/// <summary>
/// 激励视频是否就绪
/// </summary>
/// <returns></returns>
-(bool) isRewardedAdReady{
    NSLog(@"%@%@%d",TAG,@"isRewardedAdReady: ",[[AdManager getInstance]isRewardedAdReady]);
    return [[AdManager getInstance]isRewardedAdReady];
}

/// <summary>
/// 展示激励视频
/// </summary>
-(void) showRewardedAd:(NSString *) placement{
    NSLog(@"%@%@",TAG,@"showRewardedAd: ");
    [[AdManager getInstance] showRewardedAd:placement];
}

/// <summary>
/// 初始化广告
/// </summary>
/// <param name="showBanner">是否初始化banner</param>
- (void)initAD:(bool)showBanner {
    [[AdManager getInstance] initAd:showBanner];
}


#pragma mark - IAdLogEventListenter
-(void)logAdEvent:(NSString*)eventName withJson:(NSString*) jsonStr{
    [self logEvent:eventName withJson:jsonStr];
}

#pragma mark - AdListener
/// <summary>
/// Banner加载结果回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onBannerAdLoadState:(bool) isSuccess{
    NSLog(@"%@%@%d",TAG,@"onBannerAdLoadState:",isSuccess);
    [self UnitySendMessage:"OnBannerAdLoadState":isSuccess?"true":"false"];
    
}

/// <summary>
/// 插屏加载结果回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onInterstitialAdLoadState:(bool) isSuccess{
    NSLog(@"%@%@%d",TAG,@"onInterstitialAdLoadState: ",isSuccess);
    [self UnitySendMessage:"OnInterstitialAdLoadState":isSuccess?"true":"false"];
}

/// <summary>
/// 激励视频加载结果回调
/// </summary>
/// <param name="returnCode"></param>
-(void) onRewardedAdLoadState:(bool) isSuccess{
    NSLog(@"%@%@%d",TAG,@"onRewardedAdLoadState:",isSuccess);
    [self UnitySendMessage:"OnRewardedAdLoadState":isSuccess?"true":"false"];
}

/// <summary>
/// 开始播放插屏
/// </summary>
-(void) onInterstitialAdDisplay{
    NSLog(@"%@%@",TAG,@"onInterstitialAdDisplay");
    [self UnitySendMessage: "OnInterstitialAdDisplay": ""];
}

/// <summary>
/// 关闭插屏
/// </summary>
/// <param name="returnCode"></param>
-(void) onInterstitialAdHidden{
    NSLog(@"%@%@",TAG,@"onInterstitialAdHidden");
    [self UnitySendMessage:"OnInterstitialAdHidden":""];
}

/// <summary>
/// 激励视频展示成功
/// </summary>
/// <param name="returnCode"></param>
-(void) onRewardedAdDisplay{
    NSLog(@"%@%@",TAG,@"onRewardedAdDisplay");
    [self UnitySendMessage:"OnRewardedAdDisplay":""];
}

/// <summary>
/// 激励视频结束
/// </summary>
/// <param name="returnCode"></param>
-(void) onRewardedAdComplete{
    NSLog(@"%@%@",TAG,@"onRewardedAdComplete");
    [self UnitySendMessage:"OnRewardedAdComplete":""];
}

/// <summary>
/// 关闭激励视频
/// </summary>
/// <param name="returnCode">是否看完,true:播放完,false:未播放完</param>
-(void) onRewardedAdHidden:(bool) isWatchCompleted{
    NSLog(@"%@%@",TAG,@"onRewardedAdHidden");
    [self UnitySendMessage:"OnRewardedAdHidden":isWatchCompleted?"true":"false"];
}

/// <summary>
/// 观看视频结束,需在此发放奖励
/// </summary>
/// <param name="returnCode"></param>

-(void) onUserRewarded{
    NSLog(@"%@%@",TAG,@"onUserRewarded");
    [self UnitySendMessage:"OnUserRewarded":""];
    
}

@end
